module.exports = {
  apps: [
    {
      name: 'telechatebot',
      script: './dist/app.js',
      instances: 1, // Telegram Bot polling should run as a single instance unless using webhooks & Redis pub/sub
      exec_mode: 'fork',
      watch: false,
      max_memory_restart: '500M',
      env: {
        NODE_ENV: 'production',
      },
      env_development: {
        NODE_ENV: 'development',
      },
      error_file: './logs/err.log',
      out_file: './logs/out.log',
      log_file: './logs/combined.log',
      time: true,
    },
  ],
};
