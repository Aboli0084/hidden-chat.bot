# 🤖 TeleChateBot Clone - Advanced Anonymous Telegram Chat Bot
### ربات پیشرفته چت ناشناس تلگرام (مشابه @TeleChateBot) با معماری مدرن و آماده استقرار در تولید

[![TypeScript](https://img.shields.io/badge/TypeScript-5.4-blue.svg)](https://www.typescriptlang.org/)
[![Node.js](https://img.shields.io/badge/Node.js-22%2B-green.svg)](https://nodejs.org/)
[![grammY](https://img.shields.io/badge/grammY-1.45-0088cc.svg)](https://grammy.dev/)
[![Prisma](https://img.shields.io/badge/Prisma-6.19-2d3748.svg)](https://www.prisma.io/)
[![Redis & BullMQ](https://img.shields.io/badge/Redis_%26_BullMQ-Queue-dc382d.svg)](https://bullmq.io/)
[![PM2 & Docker](https://img.shields.io/badge/PM2_%26_Docker-Production-2496ed.svg)](https://pm2.keymetrics.io/)

---

## 🌟 معرفی پروژه (Overview)
این پروژه یک ربات **چت ناشناس حرفه‌ای و پیشرفته تلگرام** با معماری **Clean Architecture** و **Repository Pattern** است که با الهام از ربات‌های محبوبی همچون `@TeleChateBot` طراحی و پیاده‌سازی شده است. 

تمام اصول **SOLID** در توسعه این پروژه رعایت شده و از مدرن‌ترین ابزارهای اکوسیستم جاوا اسکریپت و تایپ اسکریپت از جمله **Node.js 22+**، فریم‌ورک قدرتمند **grammY**، دیتابیس **PostgreSQL** با اورم **Prisma** و همچنین **Redis** همراه با **BullMQ** برای مدیریت صف‌های تطبیق (Matchmaking) و برادکست استفاده شده است.

پروژه به صورت کامل برای اجرا روی هاست‌های تخصصی ربات تلگرام مانند **[TeleBotHost.com](https://telebothost.com)** و سرورهای ابری (VPS / Docker / PM2) بهینه‌سازی شده است.

---

## 🚀 ویژگی‌های کلیدی (Key Features)

### 💬 سیستم چت ناشناس و تطبیق هوشمند (Anonymous Matchmaking)
- **جستجوی فوری و تصادفی:** ورود به صف انتظار و اتصال کسری از ثانیه با کاربران آنلاین.
- **فیلترهای پیشرفته جستجو:** امکان جستجو بر اساس **جنسیت** (آقا/خانم) و **کشور** (ایران، ترکیه، روسیه، عربستان و...).
- **جستجوی اولویت‌دار (VIP Priority):** قرارگیری در ابتدای صف انتظار با کسر سکه یا اشتراک ویژه.
- **انتقال امن و ناشناس پیام‌ها (Media Relay):** پشتیبانی کامل از متن، عکس، ویدیو، ویس، موزیک، استیکر و گیف بدون افشای هویت طرفین.
- **اعلام وضعیت در حال نوشتن (Typing Indicators):** شبیه‌سازی دقیق وضعیت نوشتن یا ارسال ویس در چت.
- **ارزیابی و امتیازدهی به هم‌صحبت:** امکان لایک/دیس‌لایک هم‌صحبت پس از قطع مکالمه و تاثیر در اعتبار کاربر.
- **جلوگیری از تکرار هم‌صحبت:** عدم اتصال مجدد به ۵ هم‌صحبت اخیر جهت تنوع در گفتگوها.

### 👤 سیستم مدیریت کاربران و پروفایل (User & Profile System)
- پروفایل اختصاصی با امکان تنظیم نام، سن، جنسیت، کشور و بیوگرافی.
- ثبت زمان آخرین بازدید (Last Online) و آمار دقیق مکالمات و لایک‌های دریافتی.
- سیستم ارتقای سطح (Level Up) بر اساس میزان فعالیت (XP).

### 💰 اقتصاد داخلی و گیمیفیکیشن (Economy & Gamification)
- **سیستم سکه (Coins):** کسب سکه از طریق پاداش ورود روزانه (Daily Login)، زیرمجموعه‌گیری و گردونه شانس (Lucky Spin).
- **سیستم زیرمجموعه‌گیری پیشرفته (Referral System):** تولید لینک اختصاصی دعوت و اهدای ۲۵ سکه پاداش به دعوت‌کننده و دعوت‌شده.
- **اشتراک ویژه (VIP Premium):** خرید اشتراک‌های ۱ ماهه، ۳ ماهه و مادام‌العمر با سکه جهت استفاده نامحدود از فیلترهای جستجو و نشان ویژه 🌟.
- **جدول امتیازات برتر (Leaderboard):** نمایش کاربران برتر بر اساس سطح و مکالمات موفق در کشِ ریدیس.

### 🛡️ امنیت، ضد اسپم و مدیریت (Safety & Admin Panel)
- **کپچای تعاملی ضد ربات (Interactive Captcha):** تایید هویت کاربران جدید قبل از ورود به ربات با دکمه‌های شیشه‌ای تصادفی.
- **سیستم محدودیت نرخ (Rate Limiter):** جلوگیری از اسپم پیام (حداکثر ۱۰ پیام در ۵ ثانیه) با استفاده از Redis Token Bucket.
- **گزارش تخلف و بن خودکار (Automated Moderation):** امکان ریپورت هم‌صحبت متخلف؛ مسدودسازی خودکار کاربر در صورت دریافت ۵ گزارش تایید شده.
- **پنل مدیریت قدرتمند سوپر ادمین (/admin):**
  - مشاهده آمار زنده و روزانه (تعداد کاربران کل، آنلاین، مکالمات فعال، سکه‌های توزیع شده).
  - برادکست و ارسال پیام همگانی (متن، عکس، ویدیو) با سرعت بالا توسط کارگران پس‌زمینه **BullMQ** بدون بلاک شدن ربات.
  - مدیریت کاربران: بن/آن‌بن کردن، اهدای سکه یا اشتراک ویژه VIP به صورت مستقیم از داخل ربات.

### 🌍 چندزبانه بودن (Multi-language Support - i18n)
پشتیبانی کامل از ۵ زبان زنده با تغییر فوری از طریق تنظیمات:
- 🇮🇷 فارسی (Persian)
- 🇬🇧 انگلیسی (English)
- 🇸🇦 عربی (Arabic)
- 🇷🇺 روسی (Russian)
- 1️⃣ ترکی استانبولی (Turkish)

---

## 🏗️ معماری فنی (Technical Architecture)

```
src/
├── app.ts                 # نقطه ورود اصلی و مدیریت چرخه‌ی حیات (Graceful Shutdown)
├── bot/                   # تنظیمات grammY، استخر اتصال و ذخیره‌سازی نشست در Redis
├── config/                # متغیرهای محیطی با Zod Validation و ثابت‌های پروژه
├── controllers/           # کنترلرهای کنترل جریان (Start, Search, Chat, Profile, Economy, Admin)
├── core/                  # کانتینر تزریق وابستگی (TSyringe DI)، خطاها و 인터페이스‌ها
├── database/              # کلاینت‌های سینگلتون Prisma (PostgreSQL) و ioredis
├── keyboards/             # سازنده‌های کیبورد شیشه‌ای (Inline) و عادی (Reply) با نوار مسیر
├── locales/               # فایل‌های ترجمه JSON چندزبانه
├── middlewares/           # لایه‌های میانی (Auth, RateLimit, BanCheck, Captcha, Logger, i18n)
├── repositories/          # پیاده‌سازی الگوی Repository برای تفکیک منطق داده از منطق تجاری
├── services/              # لایه منطق تجاری (MatchService, ChatService, SafetyService و...)
└── types/                 # تعاریف تایپ‌های سفارشی برای تایپ اسکریپت و grammY Context
```

---

## 📋 پیش‌نیازها (Prerequisites)
برای اجرای پروژه روی سیستم شخصی یا سرور به موارد زیر نیاز دارید:
- **Node.js** نسخه 22 یا بالاتر
- **PostgreSQL** نسخه 14 یا بالاتر
- **Redis** نسخه 6 یا بالاتر
- **npm** یا **pnpm** یا **yarn**

---

## ⚡ نصب و راه‌اندازی سریع (Quick Start)

### ۱. دریافت پروژه و نصب وابستگی‌ها
```bash
git clone https://github.com/yourusername/telechatebot-clone.git
cd telechatebot-clone
npm install --no-audit
```

### ۲. تنظیم متغیرهای محیطی
فایل نمونه `.env.example` را به `.env` کپی کرده و اطلاعات خود را وارد کنید:
```bash
cp .env.example .env
```
مهم‌ترین تنظیمات در فایل `.env`:
```env
NODE_ENV=production
BOT_TOKEN="YOUR_TELEGRAM_BOT_TOKEN"
BOT_USERNAME="YourBotUsername"
SUPER_ADMIN_IDS="123456789,987654321"

DATABASE_URL="postgresql://dbuser:dbpass@localhost:5432/telechate?schema=public"
REDIS_HOST="127.0.0.1"
REDIS_PORT=6379
```

### ۳. ساخت و مایگریشن دیتابیس (Prisma)
```bash
# تولید تایپ‌های Prisma Client
npx prisma generate

# اعمال اسکیما روی دیتابیس و ایجاد جداول
npx prisma db push

# اجرای فایل سید برای ایجاد تنظیمات پیش‌فرض و ادمین‌های اولیه
npx ts-node prisma/seed.ts
```

### ۴. کامپایل پروژه (Build)
```bash
npm run build
```

### ۵. اجرای پروژه در حالت توسعه (Development)
```bash
npm run dev
```

### ۶. اجرای پروژه در تولید (Production) با PM2
```bash
# اجرای ربات با PM2
npm run start:prod
# یا به صورت مستقیم:
npx pm2 start ecosystem.config.js

# مشاهده لاگ‌ها
npx pm2 logs telechatebot
```

---

## 📚 راهنمای مستندات تخصصی (Documentation)
برای مطالعه جزئیات بیشتر، به مستندات موجود در پوشه `docs/` مراجعه کنید:
- 📖 [راهنمای نصب و پیکربندی (INSTALLATION.md)](./docs/INSTALLATION.md)
- 🌐 [راهنمای استقرار روی هاست TeleBotHost.com و سرور (DEPLOYMENT.md)](./docs/DEPLOYMENT.md)
- 👑 [راهنمای کامل پنل مدیریت و سوپر ادمین (ADMIN_GUIDE.md)](./docs/ADMIN_GUIDE.md)
- 🔌 [مستندات معماری، سرویس‌ها و API داخلی (API_DOCUMENTATION.md)](./docs/API_DOCUMENTATION.md)

---

## 🛡️ لایسنس (License)
این پروژه تحت لایسنس **MIT** منتشر شده است. استفاده و توسعه آن با ذکر منبع مجاز است.
