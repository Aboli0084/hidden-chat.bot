export interface IRepository<T, ID = number> {
  findById(id: ID): Promise<T | null>;
  findAll(filter?: Record<string, any>, options?: { skip?: number; take?: number }): Promise<T[]>;
  create(data: any): Promise<T>;
  update(id: ID, data: any): Promise<T>;
  delete(id: ID): Promise<boolean>;
}
