import 'reflect-metadata';
import { container } from 'tsyringe';

// DI Tokens
export const TOKENS = {
  PrismaClient: Symbol('PrismaClient'),
  RedisClient: Symbol('RedisClient'),
  UserRepository: Symbol('UserRepository'),
  ProfileRepository: Symbol('ProfileRepository'),
  ChatRepository: Symbol('ChatRepository'),
  MessageRepository: Symbol('MessageRepository'),
  ReportRepository: Symbol('ReportRepository'),
  CoinRepository: Symbol('CoinRepository'),
  PremiumRepository: Symbol('PremiumRepository'),
  ReferralRepository: Symbol('ReferralRepository'),
  AdminRepository: Symbol('AdminRepository'),
  UserService: Symbol('UserService'),
  ProfileService: Symbol('ProfileService'),
  MatchService: Symbol('MatchService'),
  ChatService: Symbol('ChatService'),
  CoinService: Symbol('CoinService'),
  PremiumService: Symbol('PremiumService'),
  ReferralService: Symbol('ReferralService'),
  SafetyService: Symbol('SafetyService'),
  GamificationService: Symbol('GamificationService'),
  AdminService: Symbol('AdminService'),
  QueueService: Symbol('QueueService'),
};

export { container };
