export class AppError extends Error {
  public readonly statusCode: number;
  public readonly isOperational: boolean;
  public readonly errorCode?: string;

  constructor(message: string, statusCode = 500, errorCode?: string, isOperational = true) {
    super(message);
    Object.setPrototypeOf(this, new.target.prototype);
    this.statusCode = statusCode;
    this.errorCode = errorCode;
    this.isOperational = isOperational;
    Error.captureStackTrace(this, this.constructor);
  }
}

export class NotFoundError extends AppError {
  constructor(message = 'Resource not found', errorCode = 'NOT_FOUND') {
    super(message, 404, errorCode);
  }
}

export class UnauthorizedError extends AppError {
  constructor(message = 'Unauthorized access', errorCode = 'UNAUTHORIZED') {
    super(message, 401, errorCode);
  }
}

export class ForbiddenError extends AppError {
  constructor(message = 'Forbidden action', errorCode = 'FORBIDDEN') {
    super(message, 403, errorCode);
  }
}

export class InsufficientCoinsError extends AppError {
  constructor(message = 'Not enough coins to perform this action') {
    super(message, 400, 'INSUFFICIENT_COINS');
  }
}

export class UserBannedError extends AppError {
  constructor(message = 'You are banned from using this bot', public readonly reason?: string) {
    super(message, 403, 'USER_BANNED');
  }
}
