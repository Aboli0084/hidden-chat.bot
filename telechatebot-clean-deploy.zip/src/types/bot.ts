import { Context, SessionFlavor } from 'grammy';
import { HydrateFlavor } from '@grammyjs/hydrate';
import { ConversationFlavor } from '@grammyjs/conversations';
import { User as PrismaUser, Profile as PrismaProfile, PremiumSubscription } from '@prisma/client';

export interface SessionData {
  userId?: number;
  userRole?: string;
  locale?: string;
  isVIP?: boolean;
  isCaptchaVerified?: boolean;
  adminState?: string;
  step?: string;
  searchFilter?: {
    gender?: string;
    country?: string;
    minAge?: number;
    maxAge?: number;
    interests?: string[];
    priority?: boolean;
  };
  tempData?: Record<string, any>;
  lastMessageId?: number;
}

export interface UserWithProfile extends PrismaUser {
  profile: PrismaProfile | null;
  premium?: PremiumSubscription | null;
}

export type BotContext = HydrateFlavor<Context> &
  SessionFlavor<SessionData> &
  ConversationFlavor & {
    // Custom properties injected by middlewares
    dbUser?: UserWithProfile;
    locale: string;
    t: (key: string, params?: Record<string, any>) => string;
    replyWithAutoDelete: (text: string, delayMs?: number, extra?: any) => Promise<any>;
  };
