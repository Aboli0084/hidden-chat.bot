import { Gender } from '@prisma/client';

export interface MatchFilter {
  gender?: Gender;
  country?: string;
  minAge?: number;
  maxAge?: number;
  interests?: string[];
  priority?: boolean;
}

export interface MatchQueueItem {
  userId: number;          // Prisma User ID (int)
  telegramId: string;      // Telegram ID string
  gender: Gender;
  age?: number;
  country: string;
  interests: string[];
  isVIP: boolean;          // Premium or paid priority
  filters: MatchFilter;
  joinedAt: number;        // Timestamp in ms
}

export interface ActiveChatSession {
  sessionId: number;       // Prisma ChatSession ID
  partnerA: {
    userId: number;
    telegramId: string;
  };
  partnerB: {
    userId: number;
    telegramId: string;
  };
  startedAt: number;
  status: 'ACTIVE' | 'ENDED' | 'REPORTED';
}
