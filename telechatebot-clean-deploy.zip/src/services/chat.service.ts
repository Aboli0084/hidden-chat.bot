import { injectable, inject } from 'tsyringe';
import { Api } from 'grammy';
import { MessageType, ChatStatus } from '@prisma/client';
import { TOKENS } from '../core/container';
import { ChatRepository } from '../repositories/chat.repository';
import { MessageRepository } from '../repositories/message.repository';
import { ProfileRepository } from '../repositories/profile.repository';
import { UserRepository } from '../repositories/user.repository';
import { MatchService } from './match.service';
import { ActiveChatSession } from '../types/match';
import { logger } from '../config/logger';

@injectable()
export class ChatService {
  constructor(
    @inject(TOKENS.ChatRepository) private chatRepo: ChatRepository,
    @inject(TOKENS.MessageRepository) private messageRepo: MessageRepository,
    @inject(TOKENS.ProfileRepository) private profileRepo: ProfileRepository,
    @inject(TOKENS.UserRepository) private userRepo: UserRepository,
    @inject(TOKENS.MatchService) private matchService: MatchService,
  ) {}

  /**
   * Relay text or media message anonymously from sender to receiver
   */
  async relayMessage(
    api: Api,
    session: ActiveChatSession,
    senderTelegramId: string,
    messageId: number,
    messageType: MessageType,
    text?: string,
    mediaFileId?: string,
  ): Promise<boolean> {
    const isSenderA = session.partnerA.telegramId === senderTelegramId;
    const sender = isSenderA ? session.partnerA : session.partnerB;
    const receiver = isSenderA ? session.partnerB : session.partnerA;

    try {
      // Use copyMessage for true anonymity (no "Forwarded from" header)
      await api.copyMessage(receiver.telegramId, sender.telegramId, messageId);

      // Log message asynchronously in DB
      await this.messageRepo.logMessage(
        session.sessionId,
        sender.userId,
        receiver.userId,
        messageType,
        text,
        mediaFileId,
      );

      // Increment session message count
      await this.chatRepo.incrementMessageCount(session.sessionId);

      return true;
    } catch (error: any) {
      logger.error(`Failed to relay message in session ${session.sessionId}:`, error?.message);
      // If user blocked bot or deleted account, end session
      if (error?.message?.includes('bot was blocked') || error?.message?.includes('user is deactivated')) {
        await this.matchService.endSessionIfActive(senderTelegramId);
        try {
          await api.sendMessage(
            sender.telegramId,
            '❌ مخاطب شما ربات را مسدود کرد یا از چت خارج شد. گفتگو پایان یافت.',
          );
        } catch {
          // Ignore
        }
      }
      return false;
    }
  }

  /**
   * Relay chat action (typing, record_voice, record_video, etc.) to partner
   */
  async relayChatAction(
    api: Api,
    session: ActiveChatSession,
    senderTelegramId: string,
    action: 'typing' | 'upload_photo' | 'record_voice' | 'record_video' | 'upload_document',
  ): Promise<void> {
    const isSenderA = session.partnerA.telegramId === senderTelegramId;
    const receiver = isSenderA ? session.partnerB : session.partnerA;

    try {
      await api.sendChatAction(receiver.telegramId, action);
    } catch {
      // Ignore chat action failures
    }
  }

  /**
   * End current chat session by user request
   */
  async endChat(telegramId: string): Promise<ActiveChatSession | null> {
    return this.matchService.endSessionIfActive(telegramId);
  }

  /**
   * Rate partner after chat ends (+XP for Like)
   */
  async ratePartner(sessionId: number, raterUserId: number, rating: number): Promise<boolean> {
    const session = await this.chatRepo.rateChat(sessionId, raterUserId, rating);
    if (!session) return false;

    const partnerId = session.partnerAId === raterUserId ? session.partnerBId : session.partnerAId;

    if (rating === 1) {
      // Like: Give partner +10 XP and increment likes count
      await this.profileRepo.incrementStats(partnerId, { likes: 1, xp: 10 });
    } else if (rating === -1) {
      // Dislike: Subtract 5 XP (minimum 0)
      const partnerProfile = await this.profileRepo.findByUserId(partnerId);
      if (partnerProfile && partnerProfile.xp >= 5) {
        await this.profileRepo.incrementStats(partnerId, { xp: -5 });
      }
    }

    return true;
  }
}
