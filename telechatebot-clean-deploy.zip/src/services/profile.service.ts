import { injectable, inject } from 'tsyringe';
import { Profile, Gender } from '@prisma/client';
import { ProfileRepository } from '../repositories/profile.repository';
import { TOKENS } from '../core/container';

@injectable()
export class ProfileService {
  constructor(
    @inject(TOKENS.ProfileRepository) private profileRepo: ProfileRepository,
  ) {}

  async getProfileByUserId(userId: number): Promise<Profile | null> {
    return this.profileRepo.findByUserId(userId);
  }

  async updateGender(userId: number, gender: Gender): Promise<Profile> {
    return this.profileRepo.updateByUserId(userId, { gender });
  }

  async updateAge(userId: number, age: number): Promise<Profile> {
    return this.profileRepo.updateByUserId(userId, { age });
  }

  async updateCountry(userId: number, country: string): Promise<Profile> {
    return this.profileRepo.updateByUserId(userId, { country: country.toUpperCase() });
  }

  async updateBio(userId: number, bio: string): Promise<Profile> {
    return this.profileRepo.updateByUserId(userId, { bio });
  }

  async updateInterests(userId: number, interests: string[]): Promise<Profile> {
    const cleaned = interests.map((i) => i.trim().toLowerCase()).filter((i) => i.length > 0);
    return this.profileRepo.updateByUserId(userId, { interests: cleaned });
  }

  async incrementStats(
    userId: number,
    stats: { likes?: number; chats?: number; matches?: number; xp?: number },
  ): Promise<Profile> {
    return this.profileRepo.incrementStats(userId, stats);
  }

  async getLeaderboard(limit = 10): Promise<any[]> {
    return this.profileRepo.getLeaderboard(limit);
  }
}
