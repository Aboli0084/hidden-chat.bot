import { injectable, inject } from 'tsyringe';
import { TOKENS } from '../core/container';
import { redis, redisHelpers } from '../database/redis';
import { ChatRepository } from '../repositories/chat.repository';
import { UserRepository } from '../repositories/user.repository';
import { ProfileRepository } from '../repositories/profile.repository';
import { MatchQueueItem, MatchFilter, ActiveChatSession } from '../types/match';
import { CONSTANTS } from '../config/constants';
import { logger } from '../config/logger';

@injectable()
export class MatchService {
  constructor(
    @inject(TOKENS.ChatRepository) private chatRepo: ChatRepository,
    @inject(TOKENS.UserRepository) private userRepo: UserRepository,
    @inject(TOKENS.ProfileRepository) private profileRepo: ProfileRepository,
  ) {}

  /**
   * Start searching for a partner.
   * Returns ActiveChatSession if an immediate match is found, otherwise null (user added to queue).
   */
  async startSearch(
    userId: number,
    telegramId: string,
    filters: MatchFilter = {},
    isVIP = false,
  ): Promise<ActiveChatSession | null> {
    // 1. Remove from any existing queues or sessions first
    await this.cancelSearch(telegramId);
    await this.endSessionIfActive(telegramId);

    // 2. Fetch user profile
    const profile = await this.profileRepo.findByUserId(userId);
    const recentPartnerIds = await this.chatRepo.getRecentPartners(userId, CONSTANTS.MAX_RECENT_PARTNERS);

    const newItem: MatchQueueItem = {
      userId,
      telegramId,
      gender: profile?.gender || 'UNSPECIFIED',
      age: profile?.age || undefined,
      country: profile?.country || 'GLOBAL',
      interests: profile?.interests || [],
      isVIP: isVIP || filters.priority || false,
      filters,
      joinedAt: Date.now(),
    };

    // 3. Try to find a match in existing queues (check VIP queue first, then standard)
    const matchedItem = await this.findCompatiblePartner(newItem, recentPartnerIds);

    if (matchedItem) {
      // We found a match! Remove matchedItem from queue and create session
      await this.cancelSearch(matchedItem.telegramId);
      return await this.createSession(newItem, matchedItem);
    }

    // 4. No immediate match found, add to Redis queue
    const targetQueueKey = newItem.isVIP
      ? `${CONSTANTS.REDIS_PREFIX}${CONSTANTS.REDIS_KEYS.QUEUE_VIP}`
      : `${CONSTANTS.REDIS_PREFIX}${CONSTANTS.REDIS_KEYS.QUEUE_STANDARD}`;

    await redis.rpush(targetQueueKey, JSON.stringify(newItem));
    logger.info(`User ${telegramId} added to search queue (${newItem.isVIP ? 'VIP' : 'Standard'})`);
    return null;
  }

  /**
   * Scan Redis queues for a compatible partner
   */
  private async findCompatiblePartner(
    item: MatchQueueItem,
    recentPartnerIds: number[],
  ): Promise<MatchQueueItem | null> {
    const queueKeys = [
      `${CONSTANTS.REDIS_PREFIX}${CONSTANTS.REDIS_KEYS.QUEUE_VIP}`,
      `${CONSTANTS.REDIS_PREFIX}${CONSTANTS.REDIS_KEYS.QUEUE_STANDARD}`,
    ];

    for (const queueKey of queueKeys) {
      const listLen = await redis.llen(queueKey);
      if (listLen === 0) continue;

      // Check items in queue (up to top 50 to avoid long blocking)
      const scanLimit = Math.min(listLen, 50);
      const rawItems = await redis.lrange(queueKey, 0, scanLimit - 1);

      for (const raw of rawItems) {
        try {
          const candidate: MatchQueueItem = JSON.parse(raw);
          if (await this.isCompatible(item, candidate, recentPartnerIds)) {
            return candidate;
          }
        } catch (e) {
          logger.warn('Failed to parse queue item in findCompatiblePartner:', e);
        }
      }
    }

    return null;
  }

  /**
   * Evaluate compatibility between two searching users
   */
  private async isCompatible(
    a: MatchQueueItem,
    b: MatchQueueItem,
    aRecentPartners: number[],
  ): Promise<boolean> {
    // 1. Never match with self
    if (a.userId === b.userId || a.telegramId === b.telegramId) return false;

    // 2. Never match with recently matched partners
    if (aRecentPartners.includes(b.userId)) return false;

    // 3. Check if blocked in PostgreSQL
    const blocked = await this.userRepo.isBlocked(a.userId, b.userId);
    if (blocked) return false;

    // 4. Gender filter check
    if (a.filters.gender && a.filters.gender !== 'UNSPECIFIED') {
      if (b.gender !== a.filters.gender) return false;
    }
    if (b.filters.gender && b.filters.gender !== 'UNSPECIFIED') {
      if (a.gender !== b.filters.gender) return false;
    }

    // 5. Country filter check
    if (a.filters.country && a.filters.country !== 'GLOBAL') {
      if (b.country.toUpperCase() !== a.filters.country.toUpperCase()) return false;
    }
    if (b.filters.country && b.filters.country !== 'GLOBAL') {
      if (a.country.toUpperCase() !== b.filters.country.toUpperCase()) return false;
    }

    // 6. Age range check
    if (a.filters.minAge && b.age && b.age < a.filters.minAge) return false;
    if (a.filters.maxAge && b.age && b.age > a.filters.maxAge) return false;
    if (b.filters.minAge && a.age && a.age < b.filters.minAge) return false;
    if (b.filters.maxAge && a.age && a.age > b.filters.maxAge) return false;

    return true;
  }

  /**
   * Remove a user from all search queues in Redis
   */
  async cancelSearch(telegramId: string): Promise<boolean> {
    const queueKeys = [
      `${CONSTANTS.REDIS_PREFIX}${CONSTANTS.REDIS_KEYS.QUEUE_VIP}`,
      `${CONSTANTS.REDIS_PREFIX}${CONSTANTS.REDIS_KEYS.QUEUE_STANDARD}`,
    ];

    let removed = false;
    for (const queueKey of queueKeys) {
      const items = await redis.lrange(queueKey, 0, -1);
      for (const itemStr of items) {
        try {
          const item: MatchQueueItem = JSON.parse(itemStr);
          if (item.telegramId === telegramId) {
            await redis.lrem(queueKey, 0, itemStr);
            removed = true;
          }
        } catch {
          // Ignore parse errors
        }
      }
    }
    return removed;
  }

  /**
   * Create chat session in DB and cache in Redis
   */
  private async createSession(a: MatchQueueItem, b: MatchQueueItem): Promise<ActiveChatSession> {
    // Create persistent session in PostgreSQL
    const dbSession = await this.chatRepo.create({
      partnerA: { connect: { id: a.userId } },
      partnerB: { connect: { id: b.userId } },
    });

    // Update match statistics in profiles
    await this.profileRepo.incrementStats(a.userId, { matches: 1, chats: 1 });
    await this.profileRepo.incrementStats(b.userId, { matches: 1, chats: 1 });

    const activeSession: ActiveChatSession = {
      sessionId: dbSession.id,
      partnerA: { userId: a.userId, telegramId: a.telegramId },
      partnerB: { userId: b.userId, telegramId: b.telegramId },
      startedAt: Date.now(),
      status: 'ACTIVE',
    };

    // Cache in Redis for fast O(1) message relay
    const ttl = CONSTANTS.SESSION_TIMEOUT_SEC;
    await redisHelpers.setJson(`${CONSTANTS.REDIS_PREFIX}${CONSTANTS.REDIS_KEYS.ACTIVE_SESSION_BY_USER}${a.telegramId}`, activeSession, ttl);
    await redisHelpers.setJson(`${CONSTANTS.REDIS_PREFIX}${CONSTANTS.REDIS_KEYS.ACTIVE_SESSION_BY_USER}${b.telegramId}`, activeSession, ttl);
    await redisHelpers.setJson(`${CONSTANTS.REDIS_PREFIX}${CONSTANTS.REDIS_KEYS.ACTIVE_SESSION_BY_ID}${dbSession.id}`, activeSession, ttl);

    logger.info(`🤝 Match created! Session ID: ${dbSession.id} between ${a.telegramId} and ${b.telegramId}`);
    return activeSession;
  }

  /**
   * Get active session for a user from Redis or DB fallback
   */
  async getActiveSession(telegramId: string): Promise<ActiveChatSession | null> {
    const key = `${CONSTANTS.REDIS_PREFIX}${CONSTANTS.REDIS_KEYS.ACTIVE_SESSION_BY_USER}${telegramId}`;
    let session = await redisHelpers.getJson<ActiveChatSession>(key);

    if (!session) {
      // Fallback: Check PostgreSQL if Redis restarted or evicted
      const user = await this.userRepo.findByTelegramId(telegramId);
      if (!user) return null;

      const dbSession = await this.chatRepo.findActiveChatByUserId(user.id);
      if (dbSession) {
        const userA = await this.userRepo.findById(dbSession.partnerAId);
        const userB = await this.userRepo.findById(dbSession.partnerBId);
        if (userA && userB) {
          session = {
            sessionId: dbSession.id,
            partnerA: { userId: userA.id, telegramId: userA.telegramId },
            partnerB: { userId: userB.id, telegramId: userB.telegramId },
            startedAt: dbSession.startedAt.getTime(),
            status: 'ACTIVE',
          };
          // Re-cache in Redis
          await redisHelpers.setJson(key, session, CONSTANTS.SESSION_TIMEOUT_SEC);
        }
      }
    }

    return session;
  }

  /**
   * End session if one exists for user
   */
  async endSessionIfActive(telegramId: string): Promise<ActiveChatSession | null> {
    const session = await this.getActiveSession(telegramId);
    if (!session) return null;

    // Remove from Redis
    await redisHelpers.deleteKey(`${CONSTANTS.REDIS_PREFIX}${CONSTANTS.REDIS_KEYS.ACTIVE_SESSION_BY_USER}${session.partnerA.telegramId}`);
    await redisHelpers.deleteKey(`${CONSTANTS.REDIS_PREFIX}${CONSTANTS.REDIS_KEYS.ACTIVE_SESSION_BY_USER}${session.partnerB.telegramId}`);
    await redisHelpers.deleteKey(`${CONSTANTS.REDIS_PREFIX}${CONSTANTS.REDIS_KEYS.ACTIVE_SESSION_BY_ID}${session.sessionId}`);

    // Update DB status
    await this.chatRepo.endChat(session.sessionId);
    logger.info(`⏹ Session ${session.sessionId} ended by ${telegramId}.`);

    return session;
  }
}
