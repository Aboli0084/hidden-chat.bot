import { injectable, inject } from 'tsyringe';
import { User, UserRole, UserStatus } from '@prisma/client';
import { UserRepository } from '../repositories/user.repository';
import { TOKENS } from '../core/container';
import { config, CONSTANTS } from '../config';
import { logger } from '../config/logger';

@injectable()
export class UserService {
  constructor(
    @inject(TOKENS.UserRepository) private userRepo: UserRepository,
  ) {}

  async getOrCreateUser(
    telegramIdStr: string,
    username?: string,
    firstName?: string,
    lastName?: string,
    languageCode = 'en',
    referredByCode?: string,
  ): Promise<{ user: User; isNew: boolean }> {
    let user = await this.userRepo.findByTelegramId(telegramIdStr);

    if (user) {
      // Update basic info if changed
      if (user.username !== username || user.firstName !== firstName) {
        user = await this.userRepo.updateByTelegramId(telegramIdStr, {
          username,
          firstName,
          lastName,
        });
      }
      await this.userRepo.updateLastOnline(telegramIdStr);
      return { user, isNew: false };
    }

    // Determine Role
    const isSuperAdmin = config.SUPER_ADMIN_IDS.includes(telegramIdStr);
    const role = isSuperAdmin ? UserRole.SUPER_ADMIN : UserRole.USER;

    // Generate unique referral code
    const randomSuffix = Math.random().toString(36).substring(2, 8).toUpperCase();
    const referralCode = `REF_${telegramIdStr}_${randomSuffix}`;

    // Check if referred by someone
    let referredById: number | undefined;
    if (referredByCode && referredByCode !== referralCode) {
      const referrer = await this.userRepo.findByReferralCode(referredByCode);
      if (referrer) {
        referredById = referrer.id;
        logger.info(`User ${telegramIdStr} referred by ${referrer.telegramId} (${referredByCode})`);
      }
    }

    // Create user and initial profile
    const newUser = await this.userRepo.create({
      telegramId: telegramIdStr,
      username,
      firstName,
      lastName,
      languageCode: CONSTANTS.SUPPORTED_LOCALES.includes(languageCode) ? languageCode : CONSTANTS.DEFAULT_LOCALE,
      role,
      status: UserStatus.ACTIVE,
      coins: 50, // Initial welcome gift
      referralCode,
      referredBy: referredById ? { connect: { id: referredById } } : undefined,
      profile: {
        create: {
          gender: 'UNSPECIFIED',
          country: 'GLOBAL',
          bio: 'New anonymous user',
          xp: 0,
          level: 1,
        },
      },
    });

    logger.info(`✅ New user registered: ${telegramIdStr} (ID: ${newUser.id})`);
    return { user: newUser, isNew: true };
  }

  async getUserByTelegramId(telegramIdStr: string): Promise<User | null> {
    return this.userRepo.findByTelegramId(telegramIdStr);
  }

  async updateLanguage(telegramIdStr: string, languageCode: string): Promise<User> {
    return this.userRepo.updateByTelegramId(telegramIdStr, { languageCode });
  }

  async addFavorite(userId: number, partnerId: number, note?: string): Promise<void> {
    await this.userRepo.addFavorite(userId, partnerId, note);
  }

  async getFavorites(userId: number): Promise<any[]> {
    return this.userRepo.getFavorites(userId);
  }

  async blockUser(blockerId: number, blockedId: number, reason?: string): Promise<void> {
    await this.userRepo.blockUser(blockerId, blockedId, reason);
  }

  async isBlocked(userIdA: number, userIdB: number): Promise<boolean> {
    return this.userRepo.isBlocked(userIdA, userIdB);
  }
}
