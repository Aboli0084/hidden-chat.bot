import { injectable, inject } from 'tsyringe';
import { CoinTxType } from '@prisma/client';
import { TOKENS } from '../core/container';
import { ReferralRepository } from '../repositories/referral.repository';
import { UserRepository } from '../repositories/user.repository';
import { CoinService } from './coin.service';
import { CONSTANTS } from '../config/constants';
import { logger } from '../config/logger';

@injectable()
export class ReferralService {
  constructor(
    @inject(TOKENS.ReferralRepository) private referralRepo: ReferralRepository,
    @inject(TOKENS.UserRepository) private userRepo: UserRepository,
    @inject(TOKENS.CoinService) private coinService: CoinService,
  ) {}

  /**
   * Process referral reward when a new referred user verifies/joins
   */
  async processReferralReward(newUserId: number): Promise<boolean> {
    const existingRef = await this.referralRepo.findByReferredId(newUserId);
    if (existingRef) {
      // Already rewarded
      return false;
    }

    const newUser = await this.userRepo.findById(newUserId);
    if (!newUser || !newUser.referredById) {
      return false;
    }

    const referrerId = newUser.referredById;
    const reward = CONSTANTS.REFERRAL_REWARD_COINS;

    // Create referral log
    await this.referralRepo.createReferralRecord(referrerId, newUserId, reward);

    // Reward both users!
    await this.coinService.addCoins(referrerId, reward, CoinTxType.REFERRAL_REWARD, `Referral reward for user #${newUserId}`);
    await this.coinService.addCoins(newUserId, reward, CoinTxType.REFERRAL_REWARD, `Welcome referral bonus from user #${referrerId}`);

    logger.info(`🎁 Referral reward paid: ${reward} coins to Referrer #${referrerId} and Referred #${newUserId}`);
    return true;
  }

  async getReferralStats(userId: number): Promise<{ count: number; earned: number }> {
    const count = await this.referralRepo.countReferralsByReferrer(userId);
    const earned = await this.referralRepo.getTotalRewardPaid(userId);
    return { count, earned };
  }
}
