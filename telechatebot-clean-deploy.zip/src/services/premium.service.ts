import { injectable, inject } from 'tsyringe';
import { PremiumPlan, CoinTxType } from '@prisma/client';
import { TOKENS } from '../core/container';
import { PremiumRepository } from '../repositories/premium.repository';
import { CoinService } from './coin.service';
import { CONSTANTS } from '../config/constants';
import { logger } from '../config/logger';

@injectable()
export class PremiumService {
  constructor(
    @inject(TOKENS.PremiumRepository) private premiumRepo: PremiumRepository,
    @inject(TOKENS.CoinService) private coinService: CoinService,
  ) {}

  async isVIP(userId: number): Promise<boolean> {
    return this.premiumRepo.isUserPremium(userId);
  }

  async getSubscription(userId: number) {
    return this.premiumRepo.findByUserId(userId);
  }

  async purchasePlan(userId: number, plan: PremiumPlan): Promise<{ success: boolean; expiry?: Date | null; error?: string }> {
    let priceCoins = 0;
    let durationDays: number | undefined;

    switch (plan) {
      case PremiumPlan.MONTHLY:
        priceCoins = CONSTANTS.PREMIUM_PRICES.MONTHLY;
        durationDays = 30;
        break;
      case PremiumPlan.THREE_MONTHS:
        priceCoins = CONSTANTS.PREMIUM_PRICES.THREE_MONTHS;
        durationDays = 90;
        break;
      case PremiumPlan.LIFETIME:
        priceCoins = CONSTANTS.PREMIUM_PRICES.LIFETIME;
        durationDays = undefined; // Lifetime
        break;
      default:
        return { success: false, error: 'INVALID_PLAN' };
    }

    // Deduct coins
    const deducted = await this.coinService.deductCoins(
      userId,
      priceCoins,
      CoinTxType.PREMIUM_BONUS,
      `VIP Premium Subscription (${plan})`,
    );

    if (!deducted) {
      return { success: false, error: 'INSUFFICIENT_COINS' };
    }

    // Upsert subscription
    const sub = await this.premiumRepo.upsertSubscription(userId, plan, priceCoins, durationDays);
    logger.info(`🌟 User ${userId} upgraded to VIP (${plan})`);

    return { success: true, expiry: sub.expiresAt };
  }
}
