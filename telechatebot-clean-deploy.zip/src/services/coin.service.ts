import { injectable, inject } from 'tsyringe';
import { CoinTxType } from '@prisma/client';
import { TOKENS } from '../core/container';
import { CoinRepository } from '../repositories/coin.repository';
import { UserRepository } from '../repositories/user.repository';
import { CONSTANTS } from '../config/constants';
import { logger } from '../config/logger';

@injectable()
export class CoinService {
  constructor(
    @inject(TOKENS.CoinRepository) private coinRepo: CoinRepository,
    @inject(TOKENS.UserRepository) private userRepo: UserRepository,
  ) {}

  async getBalance(userId: number): Promise<number> {
    const user = await this.userRepo.findById(userId);
    return user?.coins || 0;
  }

  async addCoins(userId: number, amount: number, type: CoinTxType, description?: string): Promise<number> {
    const updatedUser = await this.userRepo.addCoins(userId, amount);
    await this.coinRepo.logTransaction(userId, amount, type, description);
    logger.info(`💰 User ${userId} received +${amount} coins (${type})`);
    return updatedUser.coins;
  }

  async deductCoins(userId: number, amount: number, type: CoinTxType, description?: string): Promise<boolean> {
    const currentBalance = await this.getBalance(userId);
    if (currentBalance < amount) {
      return false;
    }

    await this.userRepo.addCoins(userId, -amount);
    await this.coinRepo.logTransaction(userId, -amount, type, description);
    logger.info(`💸 User ${userId} spent -${amount} coins (${type})`);
    return true;
  }

  async claimDailyReward(userId: number): Promise<{ success: boolean; amount: number; balance: number }> {
    const alreadyClaimed = await this.coinRepo.hasClaimedDailyLogin(userId);
    if (alreadyClaimed) {
      const balance = await this.getBalance(userId);
      return { success: false, amount: 0, balance };
    }

    const rewardAmount = CONSTANTS.DAILY_LOGIN_COINS;
    const newBalance = await this.addCoins(userId, rewardAmount, CoinTxType.LOGIN_REWARD, 'Daily login reward');
    return { success: true, amount: rewardAmount, balance: newBalance };
  }

  async spinWheel(userId: number): Promise<{ success: boolean; prize: number; balance: number; error?: string }> {
    const cost = 10;
    const deducted = await this.deductCoins(userId, cost, CoinTxType.LUCKY_SPIN, 'Spin Wheel Ticket');
    if (!deducted) {
      const balance = await this.getBalance(userId);
      return { success: false, prize: 0, balance, error: 'NO_COINS' };
    }

    // Spin prizes: 5, 10, 15, 20, 50, 100 coins
    const prizes = [5, 10, 10, 15, 15, 20, 25, 50, 100];
    const randomIndex = Math.floor(Math.random() * prizes.length);
    const prize = prizes[randomIndex];

    const newBalance = await this.addCoins(userId, prize, CoinTxType.LUCKY_SPIN, `Spin Wheel Prize (+${prize})`);
    return { success: true, prize, balance: newBalance };
  }
}
