import { injectable, inject } from 'tsyringe';
import { ReportReason, ReportStatus, BanType } from '@prisma/client';
import { TOKENS } from '../core/container';
import { ReportRepository } from '../repositories/report.repository';
import { AdminRepository } from '../repositories/admin.repository';
import { UserRepository } from '../repositories/user.repository';
import { redis } from '../database/redis';
import { CONSTANTS } from '../config/constants';
import { logger } from '../config/logger';

@injectable()
export class SafetyService {
  constructor(
    @inject(TOKENS.ReportRepository) private reportRepo: ReportRepository,
    @inject(TOKENS.AdminRepository) private adminRepo: AdminRepository,
    @inject(TOKENS.UserRepository) private userRepo: UserRepository,
  ) {}

  /**
   * Check message rate limit using Redis sliding window / token bucket
   * Returns true if user exceeds limit
   */
  async isRateLimited(telegramId: string, limit = CONSTANTS.RATE_LIMIT_MESSAGES, windowSec = CONSTANTS.RATE_LIMIT_WINDOW_SEC): Promise<boolean> {
    const key = `${CONSTANTS.REDIS_PREFIX}${CONSTANTS.REDIS_KEYS.RATE_LIMIT}${telegramId}`;
    const current = await redis.incr(key);

    if (current === 1) {
      await redis.expire(key, windowSec);
    }

    if (current > limit) {
      logger.warn(`⏳ Rate limit exceeded for user ${telegramId} (${current}/${limit} in ${windowSec}s)`);
      return true;
    }

    return false;
  }

  /**
   * Check if user is currently banned
   */
  async checkBanStatus(userId: number): Promise<{ isBanned: boolean; reason?: string; expiry?: Date | null }> {
    const ban = await this.adminRepo.getActiveBan(userId);
    if (!ban) return { isBanned: false };

    return {
      isBanned: true,
      reason: ban.reason,
      expiry: ban.expiresAt,
    };
  }

  /**
   * Submit a report against a user and auto-ban if threshold exceeded
   */
  async reportUser(
    reporterId: number,
    reportedUserId: number,
    reason: ReportReason,
    chatSessionId?: number,
    description?: string,
  ): Promise<void> {
    await this.reportRepo.submitReport(reporterId, reportedUserId, reason, chatSessionId, description);
    logger.info(`🚨 User #${reportedUserId} reported by #${reporterId} for ${reason}`);

    // Check auto-ban threshold
    const pendingCount = await this.reportRepo.countPendingReports(reportedUserId);
    if (pendingCount >= CONSTANTS.AUTO_BAN_REPORT_COUNT) {
      logger.warn(`⚡ Auto-banning user #${reportedUserId} due to ${pendingCount} pending reports!`);
      // Auto temporary ban for 24 hours
      await this.adminRepo.banUser(
        reportedUserId,
        reporterId, // Use reporter or system admin ID as ban source
        `Automated temporary ban: Received ${pendingCount} community reports.`,
        BanType.TEMP,
        1, // 1 day
      );
    }
  }

  async getPendingReports() {
    return this.reportRepo.findAll({ status: ReportStatus.PENDING }, { take: 20 });
  }

  async resolveReport(reportId: number, status: ReportStatus, adminNotes?: string) {
    return this.reportRepo.resolveReport(reportId, status, adminNotes);
  }
}
