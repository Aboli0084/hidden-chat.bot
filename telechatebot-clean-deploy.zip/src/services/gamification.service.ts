import { injectable, inject } from 'tsyringe';
import { TOKENS } from '../core/container';
import { ProfileRepository } from '../repositories/profile.repository';
import { redisHelpers } from '../database/redis';
import { CONSTANTS } from '../config/constants';
import { logger } from '../config/logger';

@injectable()
export class GamificationService {
  constructor(
    @inject(TOKENS.ProfileRepository) private profileRepo: ProfileRepository,
  ) {}

  /**
   * Get formatted leaderboard with Redis caching (5 minutes TTL)
   */
  async getLeaderboard(limit = 10): Promise<any[]> {
    const cacheKey = `${CONSTANTS.REDIS_PREFIX}${CONSTANTS.REDIS_KEYS.LEADERBOARD}`;
    const cached = await redisHelpers.getJson<any[]>(cacheKey);

    if (cached) {
      return cached;
    }

    const leaderboard = await this.profileRepo.getLeaderboard(limit);
    await redisHelpers.setJson(cacheKey, leaderboard, CONSTANTS.LEADERBOARD_CACHE_TTL_SEC);
    logger.debug('🏆 Leaderboard fetched from DB and cached in Redis');
    return leaderboard;
  }
}
