import { Queue, Worker, Job } from 'bullmq';
import { injectable } from 'tsyringe';
import { redis } from '../database/redis';
import { logger } from '../config/logger';

export interface BroadcastJobData {
  messageText?: string;
  mediaFileId?: string;
  mediaType?: string;
  targetUserIds: string[]; // Telegram IDs
  adminId: string;
}

@injectable()
export class QueueService {
  public broadcastQueue: Queue<BroadcastJobData>;
  private broadcastWorker?: Worker<BroadcastJobData>;

  constructor() {
    this.broadcastQueue = new Queue<BroadcastJobData>('broadcast-queue', {
      connection: redis,
    });
    logger.info('✅ BullMQ Broadcast Queue initialized.');
  }

  /**
   * Add a broadcast job to the queue
   */
  public async addBroadcastJob(data: BroadcastJobData): Promise<string> {
    const job = await this.broadcastQueue.add('send-broadcast', data, {
      removeOnComplete: true,
      removeOnFail: false,
    });
    logger.info(`📤 Broadcast job created with ID: ${job.id} for ${data.targetUserIds.length} recipients.`);
    return job.id || 'unknown';
  }

  /**
   * Register the worker that actually sends messages to users
   * We pass a sendMessageCallback that wraps bot.api.sendMessage / sendPhoto / copyMessage
   */
  public initBroadcastWorker(
    sendMessageCallback: (telegramId: string, data: BroadcastJobData) => Promise<boolean>,
  ): void {
    this.broadcastWorker = new Worker<BroadcastJobData>(
      'broadcast-queue',
      async (job: Job<BroadcastJobData>) => {
        const { targetUserIds } = job.data;
        let successCount = 0;
        let failCount = 0;

        logger.info(`🚀 Starting broadcast job ${job.id} to ${targetUserIds.length} users...`);

        for (let i = 0; i < targetUserIds.length; i++) {
          const userId = targetUserIds[i];
          try {
            const sent = await sendMessageCallback(userId, job.data);
            if (sent) successCount++;
            else failCount++;
          } catch (error) {
            failCount++;
            logger.warn(`Failed to broadcast to user ${userId}:`, error);
          }

          // Rate limit protection for Telegram API: ~25 messages per second max globally
          if (i % 20 === 0 && i > 0) {
            await new Promise((resolve) => setTimeout(resolve, 1000));
          }

          // Update job progress
          const progress = Math.round(((i + 1) / targetUserIds.length) * 100);
          await job.updateProgress(progress);
        }

        logger.info(`🏁 Broadcast job ${job.id} finished. Success: ${successCount}, Failed: ${failCount}.`);
        return { successCount, failCount };
      },
      { connection: redis, concurrency: 1 },
    );

    this.broadcastWorker.on('failed', (job, err) => {
      logger.error(`❌ Broadcast job ${job?.id} failed with error:`, err);
    });
  }

  public async close(): Promise<void> {
    await this.broadcastQueue.close();
    if (this.broadcastWorker) {
      await this.broadcastWorker.close();
    }
  }
}
