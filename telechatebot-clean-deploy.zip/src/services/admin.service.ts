import { injectable, inject } from 'tsyringe';
import { BanType, ReportStatus } from '@prisma/client';
import { TOKENS } from '../core/container';
import { AdminRepository } from '../repositories/admin.repository';
import { UserRepository } from '../repositories/user.repository';
import { ChatRepository } from '../repositories/chat.repository';
import { ReportRepository } from '../repositories/report.repository';
import { CoinRepository } from '../repositories/coin.repository';
import { QueueService } from './queue.service';
import { redis } from '../database/redis';
import { CONSTANTS } from '../config/constants';
import { logger } from '../config/logger';

@injectable()
export class AdminService {
  constructor(
    @inject(TOKENS.AdminRepository) private adminRepo: AdminRepository,
    @inject(TOKENS.UserRepository) private userRepo: UserRepository,
    @inject(TOKENS.ChatRepository) private chatRepo: ChatRepository,
    @inject(TOKENS.ReportRepository) private reportRepo: ReportRepository,
    @inject(TOKENS.CoinRepository) private coinRepo: CoinRepository,
    @inject(TOKENS.QueueService) private queueService: QueueService,
  ) {}

  /**
   * Get real-time system metrics for Super Admin dashboard
   */
  async getSystemStats(): Promise<{
    totalUsers: number;
    onlineUsers: number;
    activeChats: number;
    searchingUsers: number;
    totalCoins: number;
    pendingReports: number;
  }> {
    const totalUsers = await this.userRepo.countUsers();
    const onlineUsers = await this.userRepo.countOnlineUsers(5); // 5 min
    const activeChats = await this.chatRepo.countActiveChats();
    const pendingReports = await this.reportRepo.countPendingReports();

    // Count queue lengths in Redis
    const vipQueueLen = await redis.llen(`${CONSTANTS.REDIS_PREFIX}${CONSTANTS.REDIS_KEYS.QUEUE_VIP}`);
    const stdQueueLen = await redis.llen(`${CONSTANTS.REDIS_PREFIX}${CONSTANTS.REDIS_KEYS.QUEUE_STANDARD}`);
    const searchingUsers = vipQueueLen + stdQueueLen;

    // Estimate total coins (aggregate sum from User table)
    const aggCoins = await this.userRepo['prisma'].user.aggregate({
      _sum: { coins: true },
    });
    const totalCoins = aggCoins._sum.coins || 0;

    return {
      totalUsers,
      onlineUsers,
      activeChats,
      searchingUsers,
      totalCoins,
      pendingReports,
    };
  }

  /**
   * Start broadcast to all users via BullMQ
   */
  async startBroadcast(
    adminId: number,
    type: 'text' | 'photo' | 'video',
    content: string,
    fileId?: string,
  ): Promise<string> {
    const allUsers = await this.userRepo.findAll({}, { take: 50000 }); // Can be paginated in production
    const targetIds = allUsers.map((u) => u.telegramId);

    const jobId = await this.queueService.addBroadcastJob({
      mediaType: type,
      messageText: content,
      mediaFileId: fileId,
      targetUserIds: targetIds,
      adminId: String(adminId),
    });
    await this.adminRepo.logAction(adminId, 'BROADCAST', undefined, { jobId, targetsCount: targetIds.length });
    logger.info(`📢 Broadcast started by Admin #${adminId}. Job ID: ${jobId}, Targets: ${targetIds.length}`);

    return jobId;
  }

  async banUser(targetUserId: number, adminId: number, reason: string, banType: BanType, durationDays?: number) {
    const ban = await this.adminRepo.banUser(targetUserId, adminId, reason, banType, durationDays);
    await this.adminRepo.logAction(adminId, `BAN_${banType}`, targetUserId, { reason, durationDays });
    logger.warn(`🔨 User #${targetUserId} banned by Admin #${adminId}: ${reason}`);
    return ban;
  }

  async unbanUser(targetUserId: number, adminId: number) {
    await this.adminRepo.unbanUser(targetUserId);
    await this.adminRepo.logAction(adminId, 'UNBAN', targetUserId);
    logger.info(`✅ User #${targetUserId} unbanned by Admin #${adminId}`);
  }

  async addCoinsToUser(targetUserId: number, adminId: number, amount: number) {
    const updatedUser = await this.userRepo.addCoins(targetUserId, amount);
    await this.coinRepo.logTransaction(targetUserId, amount, 'ADMIN_GRANT' as any, `Granted by Admin #${adminId}`);
    await this.adminRepo.logAction(adminId, 'ADD_COINS', targetUserId, { amount });
    logger.info(`🪙 Admin #${adminId} granted +${amount} coins to User #${targetUserId}`);
    return updatedUser;
  }
}
