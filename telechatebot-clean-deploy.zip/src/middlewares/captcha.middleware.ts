import { NextFunction, InlineKeyboard } from 'grammy';
import { BotContext } from '../types/bot';

export async function captchaMiddleware(ctx: BotContext, next: NextFunction): Promise<void> {
  if (!ctx.from) {
    return next();
  }

  // If already verified, continue
  if (ctx.session?.isCaptchaVerified) {
    return next();
  }

  // Check if this is the captcha verification callback
  if (ctx.callbackQuery?.data === 'verify_captcha') {
    ctx.session.isCaptchaVerified = true;
    const successMsg = ctx.t ? ctx.t('captcha_success') : '🎉 Verification successful!';
    await ctx.answerCallbackQuery({ text: successMsg });
    
    try {
      await ctx.deleteMessage();
    } catch {
      // Ignore
    }
    
    return next(); // Proceed to start handler
  }

  // If not verified, prompt them with Captcha button
  const promptText = ctx.t ? ctx.t('captcha_prompt') : '🤖 Please confirm you are human:';
  const btnText = ctx.t ? ctx.t('captcha_button') : '✅ I am human';

  const keyboard = new InlineKeyboard().text(btnText, 'verify_captcha');

  try {
    if (ctx.callbackQuery) {
      await ctx.answerCallbackQuery({ text: '⚠️ Please verify first.' });
    } else {
      await ctx.reply(promptText, { reply_markup: keyboard });
    }
  } catch {
    // Ignore
  }
  // Do NOT call next(), blocking until verified
}
