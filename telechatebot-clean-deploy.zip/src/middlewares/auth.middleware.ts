import fs from 'fs';
import path from 'path';
import { NextFunction } from 'grammy';
import { BotContext } from '../types/bot';
import { container, TOKENS } from '../core/container';
import { UserService } from '../services/user.service';
import { PremiumService } from '../services/premium.service';
import { ReferralService } from '../services/referral.service';
import { CONSTANTS } from '../config/constants';
import { logger } from '../config/logger';

// Preload locale dictionaries into memory for O(1) fast translation lookup
const locales: Record<string, any> = {};
const localesDir = path.join(__dirname, '../locales');
try {
  const files = fs.readdirSync(localesDir);
  for (const file of files) {
    if (file.endsWith('.json')) {
      const lang = path.basename(file, '.json');
      const content = fs.readFileSync(path.join(localesDir, file), 'utf8');
      locales[lang] = JSON.parse(content);
    }
  }
  logger.info(`🌐 Loaded locales: ${Object.keys(locales).join(', ')}`);
} catch (err) {
  logger.error('Failed to load locales:', err);
}

/**
 * Helper to get nested translation string and interpolate variables
 */
function translate(locale: string, key: string, params?: Record<string, any>): string {
  const dict = locales[locale] || locales[CONSTANTS.DEFAULT_LOCALE] || {};
  const keys = key.split('.');
  let val = dict;

  for (const k of keys) {
    if (val && typeof val === 'object' && k in val) {
      val = val[k];
    } else {
      val = undefined;
      break;
    }
  }

  if (typeof val !== 'string') {
    // Fallback to default locale
    if (locale !== CONSTANTS.DEFAULT_LOCALE) {
      return translate(CONSTANTS.DEFAULT_LOCALE, key, params);
    }
    return key; // Return raw key if missing
  }

  if (!params) return val;

  // Replace {{param}} placeholders
  return val.replace(/\{\{(\w+)\}\}/g, (_, k) => {
    return params[k] !== undefined ? String(params[k]) : `{{${k}}}`;
  });
}

export async function authMiddleware(ctx: BotContext, next: NextFunction): Promise<void> {
  if (!ctx.from) {
    return next();
  }

  const telegramId = String(ctx.from.id);
  const username = ctx.from.username;
  const firstName = ctx.from.first_name;
  const lastName = ctx.from.last_name;
  const langCode = ctx.from.language_code || CONSTANTS.DEFAULT_LOCALE;

  // Check for referral code in /start command
  let referralCode: string | undefined;
  if (ctx.message?.text?.startsWith('/start ')) {
    const parts = ctx.message.text.split(' ');
    if (parts.length > 1 && parts[1].startsWith('REF_')) {
      referralCode = parts[1].trim();
    }
  }

  const userService = container.resolve<UserService>(TOKENS.UserService);
  const premiumService = container.resolve<PremiumService>(TOKENS.PremiumService);
  const referralService = container.resolve<ReferralService>(TOKENS.ReferralService);

  // Get or register user in database
  const { user, isNew } = await userService.getOrCreateUser(
    telegramId,
    username,
    firstName,
    lastName,
    langCode,
    referralCode,
  );

  if (isNew) {
    // Process referral reward if applicable
    await referralService.processReferralReward(user.id);
  }

  // Check VIP status
  const isVIP = await premiumService.isVIP(user.id);

  // Populate session state
  ctx.session.userId = user.id;
  ctx.session.userRole = user.role;
  ctx.session.locale = user.languageCode || CONSTANTS.DEFAULT_LOCALE;
  ctx.session.isVIP = isVIP;

  // Attach translator helper
  ctx.t = (key: string, params?: Record<string, any>) => {
    return translate(ctx.session.locale || CONSTANTS.DEFAULT_LOCALE, key, params);
  };

  await next();
}
