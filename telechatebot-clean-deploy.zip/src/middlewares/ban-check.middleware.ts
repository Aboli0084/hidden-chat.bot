import { NextFunction } from 'grammy';
import { BotContext } from '../types/bot';
import { container, TOKENS } from '../core/container';
import { SafetyService } from '../services/safety.service';

export async function banCheckMiddleware(ctx: BotContext, next: NextFunction): Promise<void> {
  if (!ctx.session?.userId) {
    return next();
  }

  const safetyService = container.resolve<SafetyService>(TOKENS.SafetyService);
  const banStatus = await safetyService.checkBanStatus(ctx.session.userId);

  if (banStatus.isBanned) {
    const reason = banStatus.reason || 'Violation of terms of service';
    const expiryStr = banStatus.expiry ? banStatus.expiry.toLocaleString(ctx.session.locale) : 'Permanent (ابد و یک روز)';

    const msg = ctx.t ? ctx.t('errors.banned', { reason, expiry: expiryStr }) : `🚫 You are banned from this bot.\nReason: ${reason}\nExpires: ${expiryStr}`;
    
    try {
      await ctx.reply(msg);
    } catch {
      // Ignore reply failure if user blocked bot
    }
    return; // Stop processing update
  }

  await next();
}
