import { NextFunction } from 'grammy';
import { BotContext } from '../types/bot';
import { logger } from '../config/logger';

export async function loggerMiddleware(ctx: BotContext, next: NextFunction): Promise<void> {
  const start = Date.now();
  const updateId = ctx.update.update_id;
  const fromId = ctx.from?.id || 'ANON';
  const username = ctx.from?.username || 'no_user';
  const text = ctx.message?.text || ctx.callbackQuery?.data || Object.keys(ctx.update).filter(k => k !== 'update_id')[0] || 'update';

  try {
    await next();
    const duration = Date.now() - start;
    logger.debug(`📨 [#${updateId}] User @${username} (${fromId}): "${String(text).slice(0, 30)}" -> Handled in ${duration}ms`);
  } catch (err: any) {
    const duration = Date.now() - start;
    logger.error(`❌ [#${updateId}] Error handling update from @${username} (${fromId}) after ${duration}ms:`, err);
    throw err;
  }
}
