import { NextFunction } from 'grammy';
import { BotContext } from '../types/bot';
import { container, TOKENS } from '../core/container';
import { SafetyService } from '../services/safety.service';

export async function rateLimitMiddleware(ctx: BotContext, next: NextFunction): Promise<void> {
  if (!ctx.from) {
    return next();
  }

  // VIP and Super Admins bypass rate limiting
  if (ctx.session?.isVIP || ctx.session?.userRole === 'SUPER_ADMIN' || ctx.session?.userRole === 'MODERATOR') {
    return next();
  }

  const telegramId = String(ctx.from.id);
  const safetyService = container.resolve<SafetyService>(TOKENS.SafetyService);
  const isLimited = await safetyService.isRateLimited(telegramId);

  if (isLimited) {
    const msg = ctx.t ? ctx.t('errors.rate_limited') : '⏳ You are sending messages too fast! Please slow down.';
    try {
      // Only reply once per window to prevent spamming the user back
      await ctx.reply(msg);
    } catch {
      // Ignore
    }
    return; // Stop processing update
  }

  await next();
}
