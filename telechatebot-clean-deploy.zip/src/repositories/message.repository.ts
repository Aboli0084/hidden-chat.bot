import { injectable } from 'tsyringe';
import { MessageLog, Prisma, MessageType } from '@prisma/client';
import { BaseRepository } from './base.repository';

@injectable()
export class MessageRepository extends BaseRepository<MessageLog, number> {
  async findById(id: number): Promise<MessageLog | null> {
    return this.prisma.messageLog.findUnique({ where: { id } });
  }

  async findAll(filter?: Prisma.MessageLogWhereInput, options?: { skip?: number; take?: number }): Promise<MessageLog[]> {
    return this.prisma.messageLog.findMany({
      where: filter,
      skip: options?.skip,
      take: options?.take,
      orderBy: { createdAt: 'desc' },
    });
  }

  async create(data: Prisma.MessageLogCreateInput): Promise<MessageLog> {
    return this.prisma.messageLog.create({ data });
  }

  async update(id: number, data: Prisma.MessageLogUpdateInput): Promise<MessageLog> {
    return this.prisma.messageLog.update({ where: { id }, data });
  }

  async delete(id: number): Promise<boolean> {
    try {
      await this.prisma.messageLog.delete({ where: { id } });
      return true;
    } catch {
      return false;
    }
  }

  async logMessage(
    chatSessionId: number,
    senderId: number,
    receiverId: number,
    messageType: MessageType,
    content?: string,
    mediaFileId?: string,
    isForwarded = false,
  ): Promise<MessageLog> {
    return this.prisma.messageLog.create({
      data: {
        chatSession: { connect: { id: chatSessionId } },
        sender: { connect: { id: senderId } },
        receiver: { connect: { id: receiverId } },
        messageType,
        content,
        mediaFileId,
        isForwarded,
      },
    });
  }

  async countTotalMessages(): Promise<number> {
    return this.prisma.messageLog.count();
  }
}
