import { injectable } from 'tsyringe';
import { CoinTransaction, Prisma, CoinTxType } from '@prisma/client';
import { BaseRepository } from './base.repository';

@injectable()
export class CoinRepository extends BaseRepository<CoinTransaction, number> {
  async findById(id: number): Promise<CoinTransaction | null> {
    return this.prisma.coinTransaction.findUnique({ where: { id } });
  }

  async findAll(filter?: Prisma.CoinTransactionWhereInput, options?: { skip?: number; take?: number }): Promise<CoinTransaction[]> {
    return this.prisma.coinTransaction.findMany({
      where: filter,
      skip: options?.skip,
      take: options?.take,
      orderBy: { createdAt: 'desc' },
    });
  }

  async create(data: Prisma.CoinTransactionCreateInput): Promise<CoinTransaction> {
    return this.prisma.coinTransaction.create({ data });
  }

  async update(id: number, data: Prisma.CoinTransactionUpdateInput): Promise<CoinTransaction> {
    return this.prisma.coinTransaction.update({ where: { id }, data });
  }

  async delete(id: number): Promise<boolean> {
    try {
      await this.prisma.coinTransaction.delete({ where: { id } });
      return true;
    } catch {
      return false;
    }
  }

  async logTransaction(userId: number, amount: number, type: CoinTxType, description?: string): Promise<CoinTransaction> {
    return this.prisma.coinTransaction.create({
      data: {
        user: { connect: { id: userId } },
        amount,
        type,
        description,
      },
    });
  }

  async hasClaimedDailyLogin(userId: number): Promise<boolean> {
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);

    const tx = await this.prisma.coinTransaction.findFirst({
      where: {
        userId,
        type: CoinTxType.LOGIN_REWARD,
        createdAt: { gte: todayStart },
      },
    });

    return tx !== null;
  }
}
