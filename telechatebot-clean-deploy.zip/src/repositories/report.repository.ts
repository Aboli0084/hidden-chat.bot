import { injectable } from 'tsyringe';
import { Report, Prisma, ReportStatus, ReportReason } from '@prisma/client';
import { BaseRepository } from './base.repository';

@injectable()
export class ReportRepository extends BaseRepository<Report, number> {
  async findById(id: number): Promise<Report | null> {
    return this.prisma.report.findUnique({
      where: { id },
      include: { reporter: true, reportedUser: true, chatSession: true },
    });
  }

  async findAll(filter?: Prisma.ReportWhereInput, options?: { skip?: number; take?: number }): Promise<Report[]> {
    return this.prisma.report.findMany({
      where: filter,
      skip: options?.skip,
      take: options?.take,
      orderBy: { createdAt: 'desc' },
      include: { reporter: true, reportedUser: true },
    });
  }

  async create(data: Prisma.ReportCreateInput): Promise<Report> {
    return this.prisma.report.create({
      data,
      include: { reporter: true, reportedUser: true },
    });
  }

  async update(id: number, data: Prisma.ReportUpdateInput): Promise<Report> {
    return this.prisma.report.update({ where: { id }, data });
  }

  async delete(id: number): Promise<boolean> {
    try {
      await this.prisma.report.delete({ where: { id } });
      return true;
    } catch {
      return false;
    }
  }

  async submitReport(
    reporterId: number,
    reportedUserId: number,
    reason: ReportReason,
    chatSessionId?: number,
    description?: string,
  ): Promise<Report> {
    const data: Prisma.ReportCreateInput = {
      reporter: { connect: { id: reporterId } },
      reportedUser: { connect: { id: reportedUserId } },
      reason,
      description,
      status: ReportStatus.PENDING,
    };
    if (chatSessionId) {
      data.chatSession = { connect: { id: chatSessionId } };
    }
    return this.create(data);
  }

  async countPendingReports(reportedUserId?: number): Promise<number> {
    const where: Prisma.ReportWhereInput = { status: ReportStatus.PENDING };
    if (reportedUserId) where.reportedUserId = reportedUserId;
    return this.prisma.report.count({ where });
  }

  async resolveReport(id: number, status: ReportStatus, adminNotes?: string): Promise<Report> {
    return this.prisma.report.update({
      where: { id },
      data: {
        status,
        adminNotes,
        resolvedAt: new Date(),
      },
    });
  }
}
