import { injectable } from 'tsyringe';
import { PremiumSubscription, Prisma, PremiumPlan } from '@prisma/client';
import { BaseRepository } from './base.repository';

@injectable()
export class PremiumRepository extends BaseRepository<PremiumSubscription, number> {
  async findById(id: number): Promise<PremiumSubscription | null> {
    return this.prisma.premiumSubscription.findUnique({ where: { id } });
  }

  async findByUserId(userId: number): Promise<PremiumSubscription | null> {
    return this.prisma.premiumSubscription.findUnique({ where: { userId } });
  }

  async findAll(filter?: Prisma.PremiumSubscriptionWhereInput, options?: { skip?: number; take?: number }): Promise<PremiumSubscription[]> {
    return this.prisma.premiumSubscription.findMany({
      where: filter,
      skip: options?.skip,
      take: options?.take,
      orderBy: { startedAt: 'desc' },
    });
  }

  async create(data: Prisma.PremiumSubscriptionCreateInput): Promise<PremiumSubscription> {
    return this.prisma.premiumSubscription.create({ data });
  }

  async update(id: number, data: Prisma.PremiumSubscriptionUpdateInput): Promise<PremiumSubscription> {
    return this.prisma.premiumSubscription.update({ where: { id }, data });
  }

  async delete(id: number): Promise<boolean> {
    try {
      await this.prisma.premiumSubscription.delete({ where: { id } });
      return true;
    } catch {
      return false;
    }
  }

  async upsertSubscription(userId: number, plan: PremiumPlan, priceCoins: number, durationDays?: number): Promise<PremiumSubscription> {
    let expiresAt: Date | null = null;
    if (durationDays && durationDays > 0) {
      expiresAt = new Date(Date.now() + durationDays * 24 * 60 * 60 * 1000);
    } // If null, it's LIFETIME

    return this.prisma.premiumSubscription.upsert({
      where: { userId },
      update: {
        plan,
        priceCoins,
        startedAt: new Date(),
        expiresAt,
        isActive: true,
      },
      create: {
        user: { connect: { id: userId } },
        plan,
        priceCoins,
        expiresAt,
        isActive: true,
      },
    });
  }

  async isUserPremium(userId: number): Promise<boolean> {
    const sub = await this.findByUserId(userId);
    if (!sub || !sub.isActive) return false;
    if (sub.expiresAt && sub.expiresAt < new Date()) {
      await this.update(sub.id, { isActive: false });
      return false;
    }
    return true;
  }
}
