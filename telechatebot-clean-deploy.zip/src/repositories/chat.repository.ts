import { injectable } from 'tsyringe';
import { ChatSession, Prisma, ChatStatus } from '@prisma/client';
import { BaseRepository } from './base.repository';

@injectable()
export class ChatRepository extends BaseRepository<ChatSession, number> {
  async findById(id: number): Promise<ChatSession | null> {
    return this.prisma.chatSession.findUnique({
      where: { id },
      include: { partnerA: true, partnerB: true },
    });
  }

  async findAll(filter?: Prisma.ChatSessionWhereInput, options?: { skip?: number; take?: number }): Promise<ChatSession[]> {
    return this.prisma.chatSession.findMany({
      where: filter,
      skip: options?.skip,
      take: options?.take,
      orderBy: { startedAt: 'desc' },
      include: { partnerA: true, partnerB: true },
    });
  }

  async create(data: Prisma.ChatSessionCreateInput): Promise<ChatSession> {
    return this.prisma.chatSession.create({
      data,
      include: { partnerA: true, partnerB: true },
    });
  }

  async update(id: number, data: Prisma.ChatSessionUpdateInput): Promise<ChatSession> {
    return this.prisma.chatSession.update({
      where: { id },
      data,
    });
  }

  async delete(id: number): Promise<boolean> {
    try {
      await this.prisma.chatSession.delete({ where: { id } });
      return true;
    } catch {
      return false;
    }
  }

  async findActiveChatByUserId(userId: number): Promise<ChatSession | null> {
    return this.prisma.chatSession.findFirst({
      where: {
        status: ChatStatus.ACTIVE,
        OR: [{ partnerAId: userId }, { partnerBId: userId }],
      },
      include: { partnerA: true, partnerB: true },
    });
  }

  async endChat(id: number, status = ChatStatus.ENDED): Promise<ChatSession> {
    return this.prisma.chatSession.update({
      where: { id },
      data: {
        status,
        endedAt: new Date(),
      },
    });
  }

  async incrementMessageCount(id: number): Promise<void> {
    await this.prisma.chatSession.update({
      where: { id },
      data: { messagesCount: { increment: 1 } },
    });
  }

  async rateChat(id: number, userId: number, rating: number): Promise<ChatSession | null> {
    const chat = await this.findById(id);
    if (!chat) return null;

    const updateData: Prisma.ChatSessionUpdateInput = {};
    if (chat.partnerAId === userId) {
      updateData.ratingA = rating;
    } else if (chat.partnerBId === userId) {
      updateData.ratingB = rating;
    }

    return this.prisma.chatSession.update({
      where: { id },
      data: updateData,
    });
  }

  async getRecentPartners(userId: number, limit = 5): Promise<number[]> {
    const recentChats = await this.prisma.chatSession.findMany({
      where: {
        OR: [{ partnerAId: userId }, { partnerBId: userId }],
      },
      orderBy: { startedAt: 'desc' },
      take: limit,
      select: { partnerAId: true, partnerBId: true },
    });

    const partnerIds = new Set<number>();
    for (const c of recentChats) {
      if (c.partnerAId !== userId) partnerIds.add(c.partnerAId);
      if (c.partnerBId !== userId) partnerIds.add(c.partnerBId);
    }
    return Array.from(partnerIds);
  }

  async countActiveChats(): Promise<number> {
    return this.prisma.chatSession.count({
      where: { status: ChatStatus.ACTIVE },
    });
  }

  async getAverageDuration(): Promise<number> {
    const completedChats = await this.prisma.chatSession.findMany({
      where: {
        status: ChatStatus.ENDED,
        endedAt: { not: null },
      },
      take: 1000,
      select: { startedAt: true, endedAt: true },
    });

    if (completedChats.length === 0) return 0;

    let totalSec = 0;
    for (const c of completedChats) {
      if (c.endedAt) {
        totalSec += (c.endedAt.getTime() - c.startedAt.getTime()) / 1000;
      }
    }
    return Math.round(totalSec / completedChats.length);
  }
}
