import { injectable } from 'tsyringe';
import { AdminLog, Prisma, UserBan, BanType } from '@prisma/client';
import { BaseRepository } from './base.repository';

@injectable()
export class AdminRepository extends BaseRepository<AdminLog, number> {
  async findById(id: number): Promise<AdminLog | null> {
    return this.prisma.adminLog.findUnique({ where: { id } });
  }

  async findAll(filter?: Prisma.AdminLogWhereInput, options?: { skip?: number; take?: number }): Promise<AdminLog[]> {
    return this.prisma.adminLog.findMany({
      where: filter,
      skip: options?.skip,
      take: options?.take,
      orderBy: { createdAt: 'desc' },
      include: { admin: true },
    });
  }

  async create(data: Prisma.AdminLogCreateInput): Promise<AdminLog> {
    return this.prisma.adminLog.create({ data });
  }

  async update(id: number, data: Prisma.AdminLogUpdateInput): Promise<AdminLog> {
    return this.prisma.adminLog.update({ where: { id }, data });
  }

  async delete(id: number): Promise<boolean> {
    try {
      await this.prisma.adminLog.delete({ where: { id } });
      return true;
    } catch {
      return false;
    }
  }

  async logAction(adminId: number, action: string, targetUserId?: number, details?: Record<string, any>): Promise<AdminLog> {
    return this.prisma.adminLog.create({
      data: {
        admin: { connect: { id: adminId } },
        action,
        targetUserId,
        details: details ? JSON.stringify(details) : undefined,
      },
    });
  }

  async banUser(userId: number, adminId: number, reason: string, banType: BanType, durationDays?: number): Promise<UserBan> {
    let expiresAt: Date | null = null;
    if (banType === BanType.TEMP && durationDays && durationDays > 0) {
      expiresAt = new Date(Date.now() + durationDays * 24 * 60 * 60 * 1000);
    }

    // Deactivate previous active bans
    await this.prisma.userBan.updateMany({
      where: { userId, isActive: true },
      data: { isActive: false },
    });

    return this.prisma.userBan.create({
      data: {
        user: { connect: { id: userId } },
        admin: { connect: { id: adminId } },
        reason,
        banType,
        expiresAt,
        isActive: true,
      },
    });
  }

  async getActiveBan(userId: number): Promise<UserBan | null> {
    const ban = await this.prisma.userBan.findFirst({
      where: { userId, isActive: true },
      orderBy: { createdAt: 'desc' },
    });

    if (!ban) return null;

    if (ban.expiresAt && ban.expiresAt < new Date()) {
      await this.prisma.userBan.update({
        where: { id: ban.id },
        data: { isActive: false },
      });
      return null;
    }

    return ban;
  }

  async unbanUser(userId: number): Promise<void> {
    await this.prisma.userBan.updateMany({
      where: { userId, isActive: true },
      data: { isActive: false },
    });
  }

  async getSetting(key: string): Promise<string | null> {
    const setting = await this.prisma.setting.findUnique({ where: { key } });
    if (!setting) return null;
    try {
      return JSON.parse(setting.value);
    } catch {
      return setting.value;
    }
  }

  async updateSetting(key: string, value: any, description?: string): Promise<void> {
    const strVal = typeof value === 'string' ? value : JSON.stringify(value);
    await this.prisma.setting.upsert({
      where: { key },
      update: { value: strVal, description },
      create: { key, value: strVal, description },
    });
  }
}
