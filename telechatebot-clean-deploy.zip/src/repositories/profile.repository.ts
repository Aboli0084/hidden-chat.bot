import { injectable } from 'tsyringe';
import { Profile, Prisma } from '@prisma/client';
import { BaseRepository } from './base.repository';

@injectable()
export class ProfileRepository extends BaseRepository<Profile, number> {
  async findById(id: number): Promise<Profile | null> {
    return this.prisma.profile.findUnique({ where: { id } });
  }

  async findByUserId(userId: number): Promise<Profile | null> {
    return this.prisma.profile.findUnique({ where: { userId } });
  }

  async findAll(filter?: Prisma.ProfileWhereInput, options?: { skip?: number; take?: number }): Promise<Profile[]> {
    return this.prisma.profile.findMany({
      where: filter,
      skip: options?.skip,
      take: options?.take,
      orderBy: { xp: 'desc' },
    });
  }

  async create(data: Prisma.ProfileCreateInput): Promise<Profile> {
    return this.prisma.profile.create({ data });
  }

  async update(id: number, data: Prisma.ProfileUpdateInput): Promise<Profile> {
    return this.prisma.profile.update({
      where: { id },
      data,
    });
  }

  async updateByUserId(userId: number, data: Prisma.ProfileUpdateInput): Promise<Profile> {
    return this.prisma.profile.update({
      where: { userId },
      data,
    });
  }

  async delete(id: number): Promise<boolean> {
    try {
      await this.prisma.profile.delete({ where: { id } });
      return true;
    } catch {
      return false;
    }
  }

  async incrementStats(
    userId: number,
    stats: { likes?: number; chats?: number; matches?: number; xp?: number },
  ): Promise<Profile> {
    const updateData: Prisma.ProfileUpdateInput = {};
    if (stats.likes) updateData.likesCount = { increment: stats.likes };
    if (stats.chats) updateData.chatsCount = { increment: stats.chats };
    if (stats.matches) updateData.matchesCount = { increment: stats.matches };
    if (stats.xp) {
      updateData.xp = { increment: stats.xp };
    }

    const updatedProfile = await this.prisma.profile.update({
      where: { userId },
      data: updateData,
    });

    // Check level progression: Level = floor(sqrt(XP / 50)) + 1
    const newLevel = Math.max(1, Math.floor(Math.sqrt(updatedProfile.xp / 50)) + 1);
    if (newLevel !== updatedProfile.level) {
      return this.prisma.profile.update({
        where: { userId },
        data: { level: newLevel },
      });
    }

    return updatedProfile;
  }

  async getLeaderboard(limit = 10): Promise<any[]> {
    return this.prisma.profile.findMany({
      take: limit,
      orderBy: [
        { level: 'desc' },
        { xp: 'desc' },
        { likesCount: 'desc' },
      ],
      include: {
        user: {
          select: {
            id: true,
            telegramId: true,
            username: true,
            firstName: true,
          },
        },
      },
    });
  }
}
