import { PrismaClient } from '@prisma/client';
import { prisma } from '../database/prisma';
import { IRepository } from '../core/interfaces/repository.interface';

export abstract class BaseRepository<T, ID = number> implements IRepository<T, ID> {
  protected prisma: PrismaClient;

  constructor() {
    this.prisma = prisma;
  }

  abstract findById(id: ID): Promise<T | null>;
  abstract findAll(filter?: Record<string, any>, options?: { skip?: number; take?: number }): Promise<T[]>;
  abstract create(data: any): Promise<T>;
  abstract update(id: ID, data: any): Promise<T>;
  abstract delete(id: ID): Promise<boolean>;
}
