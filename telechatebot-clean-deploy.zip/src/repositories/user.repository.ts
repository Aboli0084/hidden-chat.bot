import { injectable } from 'tsyringe';
import { User, Prisma, UserStatus, UserRole } from '@prisma/client';
import { BaseRepository } from './base.repository';

@injectable()
export class UserRepository extends BaseRepository<User, number> {
  async findById(id: number): Promise<User | null> {
    return this.prisma.user.findUnique({
      where: { id },
      include: { profile: true, premium: true },
    });
  }

  async findByTelegramId(telegramId: string): Promise<User | null> {
    return this.prisma.user.findUnique({
      where: { telegramId },
      include: { profile: true, premium: true },
    });
  }

  async findByReferralCode(referralCode: string): Promise<User | null> {
    return this.prisma.user.findUnique({
      where: { referralCode },
    });
  }

  async findAll(filter?: Prisma.UserWhereInput, options?: { skip?: number; take?: number }): Promise<User[]> {
    return this.prisma.user.findMany({
      where: filter,
      skip: options?.skip,
      take: options?.take,
      orderBy: { createdAt: 'desc' },
      include: { profile: true },
    });
  }

  async create(data: Prisma.UserCreateInput): Promise<User> {
    return this.prisma.user.create({
      data,
      include: { profile: true, premium: true },
    });
  }

  async update(id: number, data: Prisma.UserUpdateInput): Promise<User> {
    return this.prisma.user.update({
      where: { id },
      data,
      include: { profile: true, premium: true },
    });
  }

  async updateByTelegramId(telegramId: string, data: Prisma.UserUpdateInput): Promise<User> {
    return this.prisma.user.update({
      where: { telegramId },
      data,
      include: { profile: true, premium: true },
    });
  }

  async delete(id: number): Promise<boolean> {
    try {
      await this.prisma.user.delete({ where: { id } });
      return true;
    } catch {
      return false;
    }
  }

  async updateLastOnline(telegramId: string): Promise<void> {
    await this.prisma.user.update({
      where: { telegramId },
      data: { lastOnline: new Date() },
    });
  }

  async addCoins(id: number, amount: number): Promise<User> {
    return this.prisma.user.update({
      where: { id },
      data: {
        coins: { increment: amount },
      },
    });
  }

  async setStatus(id: number, status: UserStatus): Promise<User> {
    return this.prisma.user.update({
      where: { id },
      data: { status },
    });
  }

  async blockUser(blockerId: number, blockedId: number, reason?: string): Promise<void> {
    await this.prisma.blockedUser.upsert({
      where: { blockerId_blockedId: { blockerId, blockedId } },
      update: { reason },
      create: { blockerId, blockedId, reason },
    });
  }

  async isBlocked(userIdA: number, userIdB: number): Promise<boolean> {
    const block = await this.prisma.blockedUser.findFirst({
      where: {
        OR: [
          { blockerId: userIdA, blockedId: userIdB },
          { blockerId: userIdB, blockedId: userIdA },
        ],
      },
    });
    return block !== null;
  }

  async addFavorite(userId: number, partnerId: number, note?: string): Promise<void> {
    await this.prisma.favoritePartner.upsert({
      where: { userId_partnerId: { userId, partnerId } },
      update: { note },
      create: { userId, partnerId, note },
    });
  }

  async getFavorites(userId: number): Promise<any[]> {
    return this.prisma.favoritePartner.findMany({
      where: { userId },
      include: { partner: { include: { profile: true } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  async countUsers(filter?: Prisma.UserWhereInput): Promise<number> {
    return this.prisma.user.count({ where: filter });
  }

  async countOnlineUsers(sinceMinutes = 5): Promise<number> {
    const threshold = new Date(Date.now() - sinceMinutes * 60 * 1000);
    return this.prisma.user.count({
      where: { lastOnline: { gte: threshold } },
    });
  }
}
