import { injectable } from 'tsyringe';
import { Referral, Prisma } from '@prisma/client';
import { BaseRepository } from './base.repository';

@injectable()
export class ReferralRepository extends BaseRepository<Referral, number> {
  async findById(id: number): Promise<Referral | null> {
    return this.prisma.referral.findUnique({ where: { id } });
  }

  async findByReferredId(referredId: number): Promise<Referral | null> {
    return this.prisma.referral.findUnique({ where: { referredId } });
  }

  async findAll(filter?: Prisma.ReferralWhereInput, options?: { skip?: number; take?: number }): Promise<Referral[]> {
    return this.prisma.referral.findMany({
      where: filter,
      skip: options?.skip,
      take: options?.take,
      orderBy: { createdAt: 'desc' },
      include: { referrer: true, referred: true },
    });
  }

  async create(data: Prisma.ReferralCreateInput): Promise<Referral> {
    return this.prisma.referral.create({ data });
  }

  async update(id: number, data: Prisma.ReferralUpdateInput): Promise<Referral> {
    return this.prisma.referral.update({ where: { id }, data });
  }

  async delete(id: number): Promise<boolean> {
    try {
      await this.prisma.referral.delete({ where: { id } });
      return true;
    } catch {
      return false;
    }
  }

  async createReferralRecord(referrerId: number, referredId: number, rewardPaid: number): Promise<Referral> {
    return this.prisma.referral.create({
      data: {
        referrer: { connect: { id: referrerId } },
        referred: { connect: { id: referredId } },
        rewardPaid,
      },
    });
  }

  async countReferralsByReferrer(referrerId: number): Promise<number> {
    return this.prisma.referral.count({ where: { referrerId } });
  }

  async getTotalRewardPaid(referrerId: number): Promise<number> {
    const agg = await this.prisma.referral.aggregate({
      where: { referrerId },
      _sum: { rewardPaid: true },
    });
    return agg._sum.rewardPaid || 0;
  }
}
