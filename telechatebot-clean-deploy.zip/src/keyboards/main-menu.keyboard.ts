import { Keyboard } from 'grammy';
import { BotContext } from '../types/bot';

export function buildMainMenu(ctx: BotContext): Keyboard {
  const t = ctx.t || ((k: string) => k);

  return new Keyboard()
    .text(t('menu.search')).row()
    .text(t('menu.profile')).text(t('menu.coins')).row()
    .text(t('menu.premium')).text(t('menu.invite')).row()
    .text(t('menu.top')).text(t('menu.settings')).row()
    .text(t('menu.about'))
    .resized()
    .persistent();
}

export function buildBackKeyboard(ctx: BotContext): Keyboard {
  const t = ctx.t || ((k: string) => k);
  return new Keyboard().text(t('menu.back')).resized();
}
