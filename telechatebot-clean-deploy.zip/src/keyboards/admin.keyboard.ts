import { InlineKeyboard } from 'grammy';
import { BotContext } from '../types/bot';

export function buildAdminDashboardKeyboard(ctx: BotContext): InlineKeyboard {
  const t = ctx.t || ((k: string) => k);

  return new InlineKeyboard()
    .text(t('admin.btn_broadcast'), 'admin_broadcast')
    .text(t('admin.btn_reports'), 'admin_reports').row()
    .text(t('admin.btn_users'), 'admin_users')
    .text(t('admin.btn_settings'), 'admin_settings').row()
    .text(t('menu.back'), 'menu_back');
}

export function buildAdminUserActionsKeyboard(ctx: BotContext, targetUserId: number): InlineKeyboard {
  const t = ctx.t || ((k: string) => k);

  return new InlineKeyboard()
    .text(t('admin.btn_ban_temp'), `adm_ban_temp_${targetUserId}`)
    .text(t('admin.btn_ban_perm'), `adm_ban_perm_${targetUserId}`).row()
    .text(t('admin.btn_unban'), `adm_unban_${targetUserId}`)
    .text(t('admin.btn_add_coins'), `adm_coins_${targetUserId}`).row()
    .text('🔙 Back to Dashboard', 'menu_admin');
}
