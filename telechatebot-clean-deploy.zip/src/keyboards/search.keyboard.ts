import { InlineKeyboard, Keyboard } from 'grammy';
import { BotContext } from '../types/bot';
import { CONSTANTS } from '../config/constants';

export function buildSearchModeKeyboard(ctx: BotContext): InlineKeyboard {
  const t = ctx.t || ((k: string) => k);
  const isVIP = ctx.session?.isVIP || false;

  const costGender = isVIP ? 'FREE ✨' : `${CONSTANTS.FILTER_COST_GENDER} 🪙`;
  const costCountry = isVIP ? 'FREE ✨' : `${CONSTANTS.FILTER_COST_COUNTRY} 🪙`;
  const costVip = isVIP ? 'FREE ✨' : `${CONSTANTS.FILTER_COST_VIP} 🪙`;

  return new InlineKeyboard()
    .text(t('search.random'), 'search_mode_random').row()
    .text(t('search.by_gender', { cost: costGender }), 'search_mode_gender').row()
    .text(t('search.by_country', { cost: costCountry }), 'search_mode_country').row()
    .text(t('search.priority_vip', { cost: costVip }), 'search_mode_vip').row()
    .text(t('menu.back'), 'menu_back');
}

export function buildSearchingKeyboard(ctx: BotContext): Keyboard {
  const t = ctx.t || ((k: string) => k);
  return new Keyboard().text(t('search.cancel')).resized().persistent();
}

export function buildGenderSelectKeyboard(ctx: BotContext): InlineKeyboard {
  const t = ctx.t || ((k: string) => k);
  return new InlineKeyboard()
    .text(t('profile.gender_male'), 'filter_gender_MALE')
    .text(t('profile.gender_female'), 'filter_gender_FEMALE').row()
    .text('❌ Cancel', 'menu_back');
}
