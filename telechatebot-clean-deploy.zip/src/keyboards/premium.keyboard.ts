import { InlineKeyboard } from 'grammy';
import { BotContext } from '../types/bot';
import { CONSTANTS } from '../config/constants';

export function buildPremiumPlansKeyboard(ctx: BotContext): InlineKeyboard {
  const t = ctx.t || ((k: string) => k);

  return new InlineKeyboard()
    .text(t('premium.plan_monthly', { price: CONSTANTS.PREMIUM_PRICES.MONTHLY }), 'buy_vip_MONTHLY').row()
    .text(t('premium.plan_3months', { price: CONSTANTS.PREMIUM_PRICES.THREE_MONTHS }), 'buy_vip_THREE_MONTHS').row()
    .text(t('premium.plan_lifetime', { price: CONSTANTS.PREMIUM_PRICES.LIFETIME }), 'buy_vip_LIFETIME').row()
    .text(t('menu.back'), 'menu_back');
}
