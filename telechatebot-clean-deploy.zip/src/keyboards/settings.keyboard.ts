import { InlineKeyboard } from 'grammy';
import { BotContext } from '../types/bot';

export function buildSettingsKeyboard(ctx: BotContext): InlineKeyboard {
  const t = ctx.t || ((k: string) => k);

  return new InlineKeyboard()
    .text(t('settings.language'), 'settings_lang').row()
    .text(t('menu.back'), 'menu_back');
}

export function buildLanguageSelectKeyboard(ctx: BotContext): InlineKeyboard {
  const t = ctx.t || ((k: string) => k);

  return new InlineKeyboard()
    .text(t('settings.lang_en'), 'set_lang_en')
    .text(t('settings.lang_fa'), 'set_lang_fa').row()
    .text(t('settings.lang_ar'), 'set_lang_ar')
    .text(t('settings.lang_ru'), 'set_lang_ru').row()
    .text(t('settings.lang_tr'), 'set_lang_tr').row()
    .text(t('menu.back'), 'menu_settings');
}
