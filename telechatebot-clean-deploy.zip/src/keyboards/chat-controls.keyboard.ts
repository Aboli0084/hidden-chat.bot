import { Keyboard, InlineKeyboard } from 'grammy';
import { BotContext } from '../types/bot';

export function buildChatReplyKeyboard(ctx: BotContext): Keyboard {
  const t = ctx.t || ((k: string) => k);

  return new Keyboard()
    .text(t('chat.btn_next')).text(t('chat.btn_end'))
    .resized()
    .persistent();
}

export function buildChatInlineControls(ctx: BotContext, sessionId: number): InlineKeyboard {
  const t = ctx.t || ((k: string) => k);

  return new InlineKeyboard()
    .text(t('chat.btn_like'), `chat_like_${sessionId}`)
    .text(t('chat.btn_dislike'), `chat_dislike_${sessionId}`).row()
    .text(t('chat.btn_favorite'), `chat_fav_${sessionId}`)
    .text(t('chat.btn_report'), `chat_rep_${sessionId}`).row()
    .text(t('chat.btn_mute'), `chat_block_${sessionId}`);
}

export function buildReportReasonsKeyboard(ctx: BotContext, reportedUserId: number, sessionId?: number): InlineKeyboard {
  const t = ctx.t || ((k: string) => k);
  const sId = sessionId || 0;

  return new InlineKeyboard()
    .text(t('chat.report_reasons.spam'), `rep_sub_SPAM_${reportedUserId}_${sId}`)
    .text(t('chat.report_reasons.advertising'), `rep_sub_ADVERTISING_${reportedUserId}_${sId}`).row()
    .text(t('chat.report_reasons.scam'), `rep_sub_SCAM_${reportedUserId}_${sId}`)
    .text(t('chat.report_reasons.harassment'), `rep_sub_HARASSMENT_${reportedUserId}_${sId}`).row()
    .text(t('chat.report_reasons.adult'), `rep_sub_ADULT_CONTENT_${reportedUserId}_${sId}`)
    .text(t('chat.report_reasons.fake'), `rep_sub_FAKE_ACCOUNT_${reportedUserId}_${sId}`).row()
    .text('❌ Cancel', 'rep_cancel');
}
