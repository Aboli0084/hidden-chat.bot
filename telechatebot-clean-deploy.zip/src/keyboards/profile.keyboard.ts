import { InlineKeyboard } from 'grammy';
import { BotContext } from '../types/bot';

export function buildProfileEditKeyboard(ctx: BotContext): InlineKeyboard {
  const t = ctx.t || ((k: string) => k);

  return new InlineKeyboard()
    .text(t('profile.edit_gender'), 'edit_gender')
    .text(t('profile.edit_age'), 'edit_age').row()
    .text(t('profile.edit_country'), 'edit_country')
    .text(t('profile.edit_bio'), 'edit_bio').row()
    .text(t('profile.edit_interests'), 'edit_interests').row()
    .text(t('menu.back'), 'menu_back');
}

export function buildGenderEditKeyboard(ctx: BotContext): InlineKeyboard {
  const t = ctx.t || ((k: string) => k);

  return new InlineKeyboard()
    .text(t('profile.gender_male'), 'set_gender_MALE')
    .text(t('profile.gender_female'), 'set_gender_FEMALE')
    .text(t('profile.gender_other'), 'set_gender_OTHER').row()
    .text(t('menu.back'), 'menu_profile');
}
