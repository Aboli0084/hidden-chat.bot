import { Bot } from 'grammy';
import { PremiumPlan } from '@prisma/client';
import { BotContext } from '../types/bot';
import { container, TOKENS } from '../core/container';
import { PremiumService } from '../services/premium.service';
import { buildPremiumPlansKeyboard } from '../keyboards/premium.keyboard';

export function registerPremiumController(bot: Bot<BotContext>): void {
  // VIP Premium Menu button
  bot.hears(/premium|اشتراک ویژه|vip|премиум/i, async (ctx) => {
    await showPremiumMenu(ctx);
  });

  // Buy VIP Plan callback
  bot.callbackQuery(/^buy_vip_(MONTHLY|THREE_MONTHS|LIFETIME)$/, async (ctx) => {
    await ctx.answerCallbackQuery();
    if (!ctx.session?.userId || !ctx.match) return;
    const plan = ctx.match[1] as PremiumPlan;

    const premiumService = container.resolve<PremiumService>(TOKENS.PremiumService);
    const res = await premiumService.purchasePlan(ctx.session.userId, plan);

    if (res.success) {
      ctx.session.isVIP = true;
      const msg = ctx.t ? ctx.t('premium.purchase_success') : '🎉 Congratulations! You are now a VIP Premium member!';
      await ctx.reply(msg);
      await showPremiumMenu(ctx);
    } else if (res.error === 'INSUFFICIENT_COINS') {
      await ctx.reply('❌ Insufficient coins! Please invite friends or check your wallet.');
    }
  });
}

async function showPremiumMenu(ctx: BotContext): Promise<void> {
  if (!ctx.session?.userId) return;
  const premiumService = container.resolve<PremiumService>(TOKENS.PremiumService);
  const isVIP = await premiumService.isVIP(ctx.session.userId);
  const sub = await premiumService.getSubscription(ctx.session.userId);

  if (isVIP && sub) {
    const expiryStr = sub.expiresAt ? sub.expiresAt.toLocaleDateString() : 'Lifetime (مادام‌العمر)';
    const text = ctx.t ? ctx.t('premium.active_until', { expiry: expiryStr }) : `🌟 You are a VIP member! Expires: ${expiryStr}`;
    await ctx.reply(text, { parse_mode: 'Markdown' });
  } else {
    const text = ctx.t ? ctx.t('premium.title') : '🌟 Upgrade to VIP Premium!';
    await ctx.reply(text, { reply_markup: buildPremiumPlansKeyboard(ctx), parse_mode: 'Markdown' });
  }
}
