import { Bot, InlineKeyboard } from 'grammy';
import { BotContext } from '../types/bot';
import { container, TOKENS } from '../core/container';
import { GamificationService } from '../services/gamification.service';
import { ReferralService } from '../services/referral.service';
import { UserService } from '../services/user.service';
import { CONSTANTS } from '../config/constants';

export function registerGamificationController(bot: Bot<BotContext>): void {
  // Leaderboard Menu button
  bot.hears(/top|برترین‌ها|المتصدرين|рейтинг|liderlik/i, async (ctx) => {
    const gamificationService = container.resolve<GamificationService>(TOKENS.GamificationService);
    const topUsers = await gamificationService.getLeaderboard(10);

    let listStr = '';
    if (topUsers.length === 0) {
      listStr = 'No data available yet.';
    } else {
      topUsers.forEach((p, idx) => {
        const name = p.user?.firstName || p.user?.username || `User #${p.userId}`;
        listStr += `${idx + 1}. **${name}** - Level ${p.level} (❤️ ${p.likesCount} | 💬 ${p.chatsCount})\n`;
      });
    }

    const title = ctx.t ? ctx.t('leaderboard.title', { list: listStr }) : `🏆 **Leaderboard**\n\n${listStr}`;
    await ctx.reply(title, { parse_mode: 'Markdown' });
  });

  // Invite Friends Menu button
  bot.hears(/invite|دعوت از دوستان|دعوة|пригласить|davet/i, async (ctx) => {
    if (!ctx.session?.userId || !ctx.from) return;

    const userService = container.resolve<UserService>(TOKENS.UserService);
    const referralService = container.resolve<ReferralService>(TOKENS.ReferralService);

    const user = await userService.getUserByTelegramId(String(ctx.from.id));
    if (!user || !user.referralCode) return;

    const botUsername = ctx.me.username;
    const inviteLink = `https://t.me/${botUsername}?start=${user.referralCode}`;
    const stats = await referralService.getReferralStats(user.id);

    const text = ctx.t
      ? ctx.t('referral.title', {
          reward: CONSTANTS.REFERRAL_REWARD_COINS,
          link: inviteLink,
          count: stats.count,
          earned: stats.earned,
        })
      : `🎁 **Invite Friends & Earn!**\n\nShare your link:\n\`${inviteLink}\`\n\nInvited: ${stats.count} | Earned: ${stats.earned} Coins`;

    const kb = new InlineKeyboard()
      .url('↗️ Share with Friends', `https://t.me/share/url?url=${encodeURIComponent(inviteLink)}&text=${encodeURIComponent('Join the best Anonymous Telegram Chat Bot!')}`).row()
      .text('🔙 Back', 'menu_back');

    await ctx.reply(text, { reply_markup: kb, parse_mode: 'Markdown' });
  });

  // Settings Menu button
  bot.hears(/settings|تنظیمات|الإعدادات|настройки|ayarlar/i, async (ctx) => {
    const t = ctx.t || ((k: string) => k);
    const kb = new InlineKeyboard()
      .text(t('settings.language'), 'settings_lang').row()
      .text(t('menu.back'), 'menu_back');

    await ctx.reply(t('settings.title'), { reply_markup: kb });
  });

  // Language settings open
  bot.callbackQuery('settings_lang', async (ctx) => {
    await ctx.answerCallbackQuery();
    const t = ctx.t || ((k: string) => k);
    const kb = new InlineKeyboard()
      .text('🇺🇸 English', 'set_lang_en')
      .text('🇮🇷 فارسی', 'set_lang_fa').row()
      .text('🇸🇦 العربية', 'set_lang_ar')
      .text('🇷🇺 Русский', 'set_lang_ru').row()
      .text('🇹🇷 Türkçe', 'set_lang_tr').row()
      .text('🔙 Back', 'menu_back');

    await ctx.reply(t('settings.select_language'), { reply_markup: kb });
  });

  // Language selected callback
  bot.callbackQuery(/^set_lang_(en|fa|ar|ru|tr)$/, async (ctx) => {
    await ctx.answerCallbackQuery();
    if (!ctx.from || !ctx.match) return;
    const newLang = ctx.match[1];

    const userService = container.resolve<UserService>(TOKENS.UserService);
    await userService.updateLanguage(String(ctx.from.id), newLang);
    ctx.session.locale = newLang;

    const msg = ctx.t ? ctx.t('settings.language_updated') : '✅ Language updated!';
    await ctx.reply(msg);
  });
}
