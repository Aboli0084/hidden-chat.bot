import { Bot } from 'grammy';
import { MessageType, ReportReason } from '@prisma/client';
import { BotContext } from '../types/bot';
import { container, TOKENS } from '../core/container';
import { ChatService } from '../services/chat.service';
import { MatchService } from '../services/match.service';
import { UserService } from '../services/user.service';
import { SafetyService } from '../services/safety.service';
import { buildMainMenu } from '../keyboards/main-menu.keyboard';
import { buildReportReasonsKeyboard } from '../keyboards/chat-controls.keyboard';
import { notifyPartnerConnected } from './search.controller';
import { ActiveChatSession } from '../types/match';

export function registerChatController(bot: Bot<BotContext>): void {
  // End Chat button
  bot.hears(/end|پایان چت|إنهاء|завершить|bitir/i, async (ctx) => {
    if (!ctx.from) return;
    await terminateSessionAndNotify(ctx, String(ctx.from.id), true);
  });

  // Next Partner button
  bot.hears(/next|مخاطب بعدی|التالي|следующий|sıradaki/i, async (ctx) => {
    if (!ctx.from || !ctx.session?.userId) return;
    const telegramId = String(ctx.from.id);

    // End current chat first
    await terminateSessionAndNotify(ctx, telegramId, false);

    // Immediately start searching for new partner
    const matchService = container.resolve<MatchService>(TOKENS.MatchService);
    const activeSession = await matchService.startSearch(ctx.session.userId, telegramId, {}, ctx.session.isVIP || false);

    if (activeSession) {
      await notifyPartnerConnected(ctx, activeSession);
    } else {
      const searchingMsg = ctx.t ? ctx.t('search.searching', { mode: 'Random 🎲' }) : '⏳ Searching for new partner...';
      await ctx.reply(searchingMsg, { parse_mode: 'Markdown' });
    }
  });

  // Like callback
  bot.callbackQuery(/^chat_like_(\d+)$/, async (ctx) => {
    await ctx.answerCallbackQuery();
    if (!ctx.session?.userId || !ctx.match) return;
    const sessionId = Number(ctx.match[1]);

    const chatService = container.resolve<ChatService>(TOKENS.ChatService);
    const success = await chatService.ratePartner(sessionId, ctx.session.userId, 1);
    if (success) {
      const msg = ctx.t ? ctx.t('chat.liked', { xp: 10 }) : '❤️ Liked! Partner received +10 XP.';
      await ctx.reply(msg);
    }
  });

  // Dislike callback
  bot.callbackQuery(/^chat_dislike_(\d+)$/, async (ctx) => {
    await ctx.answerCallbackQuery();
    if (!ctx.session?.userId || !ctx.match) return;
    const sessionId = Number(ctx.match[1]);

    const chatService = container.resolve<ChatService>(TOKENS.ChatService);
    await chatService.ratePartner(sessionId, ctx.session.userId, -1);
    const msg = ctx.t ? ctx.t('chat.disliked') : '👎 Disliked.';
    await ctx.reply(msg);
  });

  // Favorite callback
  bot.callbackQuery(/^chat_fav_(\d+)$/, async (ctx) => {
    await ctx.answerCallbackQuery();
    if (!ctx.session?.userId || !ctx.match) return;
    const sessionId = Number(ctx.match[1]);

    const matchService = container.resolve<MatchService>(TOKENS.MatchService);
    const userService = container.resolve<UserService>(TOKENS.UserService);
    
    // We need to find the partner ID from sessionId
    const chatRepo = container.resolve(TOKENS.ChatRepository) as any;
    const chat = await chatRepo.findById(sessionId);
    if (chat) {
      const partnerId = chat.partnerAId === ctx.session.userId ? chat.partnerBId : chat.partnerAId;
      await userService.addFavorite(ctx.session.userId, partnerId);
      const msg = ctx.t ? ctx.t('chat.favorite_added') : '📌 Added to favorites!';
      await ctx.reply(msg);
    }
  });

  // Block callback
  bot.callbackQuery(/^chat_block_(\d+)$/, async (ctx) => {
    await ctx.answerCallbackQuery();
    if (!ctx.session?.userId || !ctx.match || !ctx.from) return;
    const sessionId = Number(ctx.match[1]);

    const userService = container.resolve<UserService>(TOKENS.UserService);
    const chatRepo = container.resolve(TOKENS.ChatRepository) as any;
    const chat = await chatRepo.findById(sessionId);

    if (chat) {
      const partnerId = chat.partnerAId === ctx.session.userId ? chat.partnerBId : chat.partnerAId;
      await userService.blockUser(ctx.session.userId, partnerId, 'Blocked during chat');
      const msg = ctx.t ? ctx.t('chat.blocked') : '🚫 User blocked.';
      await ctx.reply(msg);
      await terminateSessionAndNotify(ctx, String(ctx.from.id), true);
    }
  });

  // Report button clicked
  bot.callbackQuery(/^chat_rep_(\d+)$/, async (ctx) => {
    await ctx.answerCallbackQuery();
    if (!ctx.session?.userId || !ctx.match) return;
    const sessionId = Number(ctx.match[1]);

    const chatRepo = container.resolve(TOKENS.ChatRepository) as any;
    const chat = await chatRepo.findById(sessionId);
    if (chat) {
      const partnerId = chat.partnerAId === ctx.session.userId ? chat.partnerBId : chat.partnerAId;
      const prompt = ctx.t ? ctx.t('chat.report_prompt') : '🚫 Select report reason:';
      await ctx.reply(prompt, { reply_markup: buildReportReasonsKeyboard(ctx, partnerId, sessionId) });
    }
  });

  // Report reason submitted
  bot.callbackQuery(/^rep_sub_([A_Z]+)_(\d+)_(\d+)$/, async (ctx) => {
    await ctx.answerCallbackQuery();
    if (!ctx.session?.userId || !ctx.match || !ctx.from) return;

    const reason = ctx.match[1] as ReportReason;
    const reportedUserId = Number(ctx.match[2]);
    const sessionId = Number(ctx.match[3]);

    const safetyService = container.resolve<SafetyService>(TOKENS.SafetyService);
    await safetyService.reportUser(ctx.session.userId, reportedUserId, reason, sessionId);

    const successMsg = ctx.t ? ctx.t('chat.reported_success') : '✅ Reported successfully. Chat terminated.';
    await ctx.reply(successMsg);
    await terminateSessionAndNotify(ctx, String(ctx.from.id), true);
  });

  // Cancel report
  bot.callbackQuery('rep_cancel', async (ctx) => {
    await ctx.answerCallbackQuery();
    try {
      await ctx.deleteMessage();
    } catch {}
  });

  // Universal Message & Media Relay Handler (Must be registered after specific commands/menu items)
  bot.on(['message:text', 'message:photo', 'message:video', 'message:voice', 'message:audio', 'message:sticker', 'message:document', 'message:video_note'], async (ctx, next) => {
    if (!ctx.from) return next();

    // Check if text is a known command or menu button
    const text = ctx.message?.text || '';
    if (text.startsWith('/') || /search|شروع جستجو|profile|پروفایل|coins|سکه|premium|اشتراک|invite|دعوت|top|برترین|settings|تنظیمات|about|راهنما/i.test(text)) {
      return next();
    }

    const telegramId = String(ctx.from.id);
    const matchService = container.resolve<MatchService>(TOKENS.MatchService);
    const session = await matchService.getActiveSession(telegramId);

    if (!session) {
      // Not in chat
      const err = ctx.t ? ctx.t('errors.not_in_chat') : '❌ You are not in an active chat.';
      await ctx.reply(err, { reply_markup: buildMainMenu(ctx) });
      return;
    }

    // Determine message type
    let msgType: MessageType = MessageType.TEXT;
    let fileId: string | undefined;
    if (ctx.message.photo) {
      msgType = MessageType.PHOTO;
      fileId = ctx.message.photo[ctx.message.photo.length - 1].file_id;
    } else if (ctx.message.video) {
      msgType = MessageType.VIDEO;
      fileId = ctx.message.video.file_id;
    } else if (ctx.message.voice) {
      msgType = MessageType.VOICE;
      fileId = ctx.message.voice.file_id;
    } else if (ctx.message.audio) {
      msgType = MessageType.AUDIO;
      fileId = ctx.message.audio.file_id;
    } else if (ctx.message.sticker) {
      msgType = MessageType.STICKER;
      fileId = ctx.message.sticker.file_id;
    } else if (ctx.message.document) {
      msgType = MessageType.DOC;
      fileId = ctx.message.document.file_id;
    } else if (ctx.message.video_note) {
      msgType = MessageType.VIDEO;
      fileId = ctx.message.video_note.file_id;
    }

    const chatService = container.resolve<ChatService>(TOKENS.ChatService);
    await chatService.relayMessage(
      ctx.api,
      session,
      telegramId,
      ctx.message.message_id,
      msgType,
      text || ctx.message.caption,
      fileId,
    );
  });
}

/**
 * Terminate active session and notify both partners
 */
async function terminateSessionAndNotify(ctx: BotContext, telegramId: string, showMainMenu: boolean): Promise<void> {
  const matchService = container.resolve<MatchService>(TOKENS.MatchService);
  const endedSession = await matchService.endSessionIfActive(telegramId);

  if (!endedSession) return;

  const durationSec = Math.round((Date.now() - endedSession.startedAt) / 1000);

  // Notify initiator
  const initiatorMsg = ctx.t
    ? ctx.t('chat.ended_by_you') + `\n⏱ Duration: ${durationSec}s`
    : `❌ You ended the chat.\n⏱ Duration: ${durationSec}s`;

  if (showMainMenu) {
    await ctx.reply(initiatorMsg, { reply_markup: buildMainMenu(ctx) });
  } else {
    await ctx.reply(initiatorMsg);
  }

  // Notify partner
  const partnerTelegramId = endedSession.partnerA.telegramId === telegramId
    ? endedSession.partnerB.telegramId
    : endedSession.partnerA.telegramId;

  const partnerMsg = ctx.t
    ? ctx.t('search.partner_left', { duration: durationSec, count: '?' })
    : `❌ Your partner left the chat.\n⏱ Duration: ${durationSec}s`;

  try {
    await ctx.api.sendMessage(partnerTelegramId, partnerMsg, {
      reply_markup: buildMainMenu(ctx),
      parse_mode: 'Markdown',
    });
  } catch {
    // Ignore if partner blocked
  }
}
