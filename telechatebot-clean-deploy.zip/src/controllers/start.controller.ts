import { Bot } from 'grammy';
import { BotContext } from '../types/bot';
import { buildMainMenu } from '../keyboards/main-menu.keyboard';

export function registerStartController(bot: Bot<BotContext>): void {
  // /start command
  bot.command('start', async (ctx) => {
    const welcomeMsg = ctx.t ? ctx.t('welcome') : '🎉 Welcome to Anonymous Chat Bot!';
    await ctx.reply(welcomeMsg, {
      reply_markup: buildMainMenu(ctx),
      parse_mode: 'Markdown',
    });
  });

  // /help command
  bot.command('help', async (ctx) => {
    const aboutMsg = ctx.t ? ctx.t('about.text') : 'ℹ️ Anonymous Chat Bot Help';
    await ctx.reply(aboutMsg, {
      reply_markup: buildMainMenu(ctx),
      parse_mode: 'Markdown',
    });
  });

  // Main menu: About & Help button
  bot.hears(/about|راهنما و درباره ما|حسابي|o боте|hakkında/i, async (ctx) => {
    const aboutMsg = ctx.t ? ctx.t('about.text') : 'ℹ️ Anonymous Chat Bot v1.0';
    await ctx.reply(aboutMsg, {
      reply_markup: buildMainMenu(ctx),
      parse_mode: 'Markdown',
    });
  });

  // Back to main menu (callback or text)
  bot.callbackQuery('menu_back', async (ctx) => {
    await ctx.answerCallbackQuery();
    const welcomeMsg = ctx.t ? ctx.t('welcome') : '🎉 Welcome!';
    await ctx.reply(welcomeMsg, {
      reply_markup: buildMainMenu(ctx),
      parse_mode: 'Markdown',
    });
  });

  bot.hears(/back|بازگشت|عودة|назад|geri/i, async (ctx) => {
    const welcomeMsg = ctx.t ? ctx.t('welcome') : '🎉 Main Menu';
    await ctx.reply(welcomeMsg, {
      reply_markup: buildMainMenu(ctx),
      parse_mode: 'Markdown',
    });
  });
}
