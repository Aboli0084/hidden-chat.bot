import { Bot } from 'grammy';
import { BanType, UserRole } from '@prisma/client';
import { BotContext } from '../types/bot';
import { container, TOKENS } from '../core/container';
import { AdminService } from '../services/admin.service';
import { UserService } from '../services/user.service';
import { buildAdminDashboardKeyboard, buildAdminUserActionsKeyboard } from '../keyboards/admin.keyboard';
import { buildMainMenu } from '../keyboards/main-menu.keyboard';

export function registerAdminController(bot: Bot<BotContext>): void {
  // Guard helper: Check if user is Super Admin
  const isSuperAdmin = (ctx: BotContext) => {
    return ctx.session?.userRole === UserRole.SUPER_ADMIN || ctx.session?.userRole === UserRole.ADMIN;
  };

  // /admin command & Admin Panel button
  bot.command('admin', async (ctx) => {
    if (!isSuperAdmin(ctx)) return;
    await showAdminDashboard(ctx);
  });

  bot.hears(/admin|پنل مدیریت|لوحة التحكم|панель|yönetici/i, async (ctx) => {
    if (!isSuperAdmin(ctx)) return;
    await showAdminDashboard(ctx);
  });

  bot.callbackQuery('menu_admin', async (ctx) => {
    await ctx.answerCallbackQuery();
    if (!isSuperAdmin(ctx)) return;
    await showAdminDashboard(ctx);
  });

  // Broadcast button
  bot.callbackQuery('admin_broadcast', async (ctx) => {
    await ctx.answerCallbackQuery();
    if (!isSuperAdmin(ctx)) return;

    ctx.session.adminState = 'AWAITING_BROADCAST';
    const prompt = ctx.t ? ctx.t('admin.broadcast_prompt') : '📢 Send message, photo, or video to broadcast to all users:';
    await ctx.reply(prompt);
  });

  // User management button
  bot.callbackQuery('admin_users', async (ctx) => {
    await ctx.answerCallbackQuery();
    if (!isSuperAdmin(ctx)) return;

    ctx.session.adminState = 'AWAITING_USER_LOOKUP';
    const prompt = ctx.t ? ctx.t('admin.user_lookup') : '👥 Send Telegram ID or Username of target user:';
    await ctx.reply(prompt);
  });

  // Ban temp callback
  bot.callbackQuery(/^adm_ban_temp_(\d+)$/, async (ctx) => {
    await ctx.answerCallbackQuery();
    if (!isSuperAdmin(ctx) || !ctx.match || !ctx.session?.userId) return;
    const targetUserId = Number(ctx.match[1]);

    const adminService = container.resolve<AdminService>(TOKENS.AdminService);
    await adminService.banUser(targetUserId, ctx.session.userId, 'Temporary ban by Admin', BanType.TEMP, 1);

    await ctx.reply('✅ User banned temporarily for 24 hours.');
  });

  // Ban perm callback
  bot.callbackQuery(/^adm_ban_perm_(\d+)$/, async (ctx) => {
    await ctx.answerCallbackQuery();
    if (!isSuperAdmin(ctx) || !ctx.match || !ctx.session?.userId) return;
    const targetUserId = Number(ctx.match[1]);

    const adminService = container.resolve<AdminService>(TOKENS.AdminService);
    await adminService.banUser(targetUserId, ctx.session.userId, 'Permanent ban by Admin', BanType.PERMANENT);

    await ctx.reply('🚫 User permanently banned.');
  });

  // Unban callback
  bot.callbackQuery(/^adm_unban_(\d+)$/, async (ctx) => {
    await ctx.answerCallbackQuery();
    if (!isSuperAdmin(ctx) || !ctx.match || !ctx.session?.userId) return;
    const targetUserId = Number(ctx.match[1]);

    const adminService = container.resolve<AdminService>(TOKENS.AdminService);
    await adminService.unbanUser(targetUserId, ctx.session.userId);

    await ctx.reply('✅ User unbanned successfully.');
  });

  // Grant coins callback
  bot.callbackQuery(/^adm_coins_(\d+)$/, async (ctx) => {
    await ctx.answerCallbackQuery();
    if (!isSuperAdmin(ctx) || !ctx.match || !ctx.session?.userId) return;
    const targetUserId = Number(ctx.match[1]);

    const adminService = container.resolve<AdminService>(TOKENS.AdminService);
    await adminService.addCoinsToUser(targetUserId, ctx.session.userId, 100);

    await ctx.reply('🪙 Granted +100 coins to target user!');
  });

  // Admin state listener (must run before universal chat relay)
  bot.on('message', async (ctx, next) => {
    if (!isSuperAdmin(ctx) || !ctx.session?.adminState) {
      return next();
    }

    const state = ctx.session.adminState;
    ctx.session.adminState = undefined; // Reset state

    if (state === 'AWAITING_BROADCAST' && ctx.session.userId) {
      const adminService = container.resolve<AdminService>(TOKENS.AdminService);
      let type: 'text' | 'photo' | 'video' = 'text';
      let content = ctx.message.text || ctx.message.caption || '';
      let fileId: string | undefined;

      if (ctx.message.photo) {
        type = 'photo';
        fileId = ctx.message.photo[ctx.message.photo.length - 1].file_id;
      } else if (ctx.message.video) {
        type = 'video';
        fileId = ctx.message.video.file_id;
      }

      const jobId = await adminService.startBroadcast(ctx.session.userId, type, content, fileId);
      const msg = ctx.t ? ctx.t('admin.broadcast_started', { jobId }) : `🚀 Broadcast started! Job ID: ${jobId}`;
      await ctx.reply(msg, { reply_markup: buildMainMenu(ctx) });
      return;
    }

    if (state === 'AWAITING_USER_LOOKUP') {
      const query = ctx.message.text?.trim();
      if (!query) return next();

      const userService = container.resolve<UserService>(TOKENS.UserService);
      const user = await userService.getUserByTelegramId(query);

      if (!user) {
        await ctx.reply('❌ User not found in database.', { reply_markup: buildMainMenu(ctx) });
        return;
      }

      const details = ctx.t
        ? ctx.t('admin.user_details', {
            id: user.id,
            telegramId: user.telegramId,
            role: user.role,
            status: user.status,
            coins: user.coins,
            level: 1,
          })
        : `👤 **User Details:**\nID: ${user.id} | Telegram ID: ${user.telegramId}\nRole: ${user.role} | Coins: ${user.coins}`;

      await ctx.reply(details, {
        reply_markup: buildAdminUserActionsKeyboard(ctx, user.id),
        parse_mode: 'Markdown',
      });
      return;
    }

    return next();
  });
}

async function showAdminDashboard(ctx: BotContext): Promise<void> {
  const adminService = container.resolve<AdminService>(TOKENS.AdminService);
  const stats = await adminService.getSystemStats();

  const text = ctx.t
    ? ctx.t('admin.dashboard', stats)
    : `👑 **Super Admin Dashboard**\n\n👥 Total Users: ${stats.totalUsers}\n🟢 Online: ${stats.onlineUsers}\n💬 Active Chats: ${stats.activeChats}\n⏳ In Queue: ${stats.searchingUsers}`;

  await ctx.reply(text, {
    reply_markup: buildAdminDashboardKeyboard(ctx),
    parse_mode: 'Markdown',
  });
}
