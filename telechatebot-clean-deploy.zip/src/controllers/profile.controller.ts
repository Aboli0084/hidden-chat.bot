import { Bot } from 'grammy';
import { Gender } from '@prisma/client';
import { BotContext } from '../types/bot';
import { container, TOKENS } from '../core/container';
import { ProfileService } from '../services/profile.service';
import { buildProfileEditKeyboard, buildGenderEditKeyboard } from '../keyboards/profile.keyboard';
import { buildMainMenu } from '../keyboards/main-menu.keyboard';

export function registerProfileController(bot: Bot<BotContext>): void {
  // My Profile Menu button
  bot.hears(/profile|پروفایل من|ملفي|профиль|profilim/i, async (ctx) => {
    await showProfile(ctx);
  });

  bot.callbackQuery('menu_profile', async (ctx) => {
    await ctx.answerCallbackQuery();
    await showProfile(ctx);
  });

  // Edit Gender prompt
  bot.callbackQuery('edit_gender', async (ctx) => {
    await ctx.answerCallbackQuery();
    const prompt = ctx.t ? ctx.t('profile.select_gender') : '🚻 Select your gender:';
    await ctx.reply(prompt, { reply_markup: buildGenderEditKeyboard(ctx) });
  });

  // Set gender
  bot.callbackQuery(/^set_gender_(MALE|FEMALE|OTHER)$/, async (ctx) => {
    await ctx.answerCallbackQuery();
    if (!ctx.session?.userId || !ctx.match) return;
    const gender = ctx.match[1] as Gender;

    const profileService = container.resolve<ProfileService>(TOKENS.ProfileService);
    await profileService.updateGender(ctx.session.userId, gender);

    const msg = ctx.t ? ctx.t('profile.updated') : '✅ Profile updated!';
    await ctx.reply(msg);
    await showProfile(ctx);
  });
}

async function showProfile(ctx: BotContext): Promise<void> {
  if (!ctx.session?.userId || !ctx.from) return;

  const profileService = container.resolve<ProfileService>(TOKENS.ProfileService);
  const profile = await profileService.getProfileByUserId(ctx.session.userId);

  if (!profile) return;

  const interestsStr = profile.interests.length > 0 ? profile.interests.join(', ') : '-';
  const genderStr = profile.gender === 'MALE' ? '👨 Male' : profile.gender === 'FEMALE' ? '👩 Female' : '🌈 Other/Unspecified';

  const text = ctx.t
    ? ctx.t('profile.title', {
        id: ctx.from.id,
        gender: genderStr,
        age: profile.age || '-',
        country: profile.country || 'Global',
        bio: profile.bio || '-',
        interests: interestsStr,
        level: profile.level,
        xp: profile.xp,
        likes: profile.likesCount,
        chats: profile.chatsCount,
        matches: profile.matchesCount,
      })
    : `👤 **Your Profile**\n⭐ Level: ${profile.level} (${profile.xp} XP)\n❤️ Likes: ${profile.likesCount}\n💬 Chats: ${profile.chatsCount}`;

  await ctx.reply(text, {
    reply_markup: buildProfileEditKeyboard(ctx),
    parse_mode: 'Markdown',
  });
}
