import { Bot } from 'grammy';
import { CoinTxType } from '@prisma/client';
import { BotContext } from '../types/bot';
import { container, TOKENS } from '../core/container';
import { MatchService } from '../services/match.service';
import { CoinService } from '../services/coin.service';
import { buildSearchModeKeyboard, buildSearchingKeyboard, buildGenderSelectKeyboard } from '../keyboards/search.keyboard';
import { buildMainMenu } from '../keyboards/main-menu.keyboard';
import { buildChatReplyKeyboard, buildChatInlineControls } from '../keyboards/chat-controls.keyboard';
import { CONSTANTS } from '../config/constants';
import { ActiveChatSession } from '../types/match';

export function registerSearchController(bot: Bot<BotContext>): void {
  // Start Search Menu button
  bot.hears(/search|شروع جستجو|ابحث|поиск|ara/i, async (ctx) => {
    const msg = ctx.t ? ctx.t('search.select_mode') : '🔍 Select Matchmaking Mode:';
    await ctx.reply(msg, {
      reply_markup: buildSearchModeKeyboard(ctx),
      parse_mode: 'Markdown',
    });
  });

  // Cancel search (reply button)
  bot.hears(/cancel|لغو جستجو|إلغاء|отменить|iptal/i, async (ctx) => {
    if (!ctx.from) return;
    const matchService = container.resolve<MatchService>(TOKENS.MatchService);
    await matchService.cancelSearch(String(ctx.from.id));

    const msg = ctx.t ? ctx.t('search.cancelled') : '🚫 Search cancelled.';
    await ctx.reply(msg, {
      reply_markup: buildMainMenu(ctx),
      parse_mode: 'Markdown',
    });
  });

  // Random mode search
  bot.callbackQuery('search_mode_random', async (ctx) => {
    await ctx.answerCallbackQuery();
    await performSearch(ctx, {}, false);
  });

  // VIP priority search
  bot.callbackQuery('search_mode_vip', async (ctx) => {
    await ctx.answerCallbackQuery();
    if (!ctx.session?.userId || !ctx.from) return;

    const isVIP = ctx.session.isVIP || false;
    if (!isVIP) {
      // Deduct coins if not VIP
      const coinService = container.resolve<CoinService>(TOKENS.CoinService);
      const cost = CONSTANTS.FILTER_COST_VIP;
      const success = await coinService.deductCoins(ctx.session.userId, cost, CoinTxType.SPEND_FILTER, 'VIP Priority Search Filter');
      if (!success) {
        const balance = await coinService.getBalance(ctx.session.userId);
        const err = ctx.t ? ctx.t('search.no_coins', { cost, balance }) : `❌ Insufficient coins (${balance}/${cost})`;
        await ctx.reply(err, { reply_markup: buildSearchModeKeyboard(ctx) });
        return;
      }
    }

    await performSearch(ctx, { priority: true }, true);
  });

  // Gender filter selection prompt
  bot.callbackQuery('search_mode_gender', async (ctx) => {
    await ctx.answerCallbackQuery();
    const msg = ctx.t ? ctx.t('profile.select_gender') : '🚻 Select preferred partner gender:';
    await ctx.reply(msg, { reply_markup: buildGenderSelectKeyboard(ctx) });
  });

  // Gender filter selected
  bot.callbackQuery(/^filter_gender_(MALE|FEMALE)$/, async (ctx) => {
    await ctx.answerCallbackQuery();
    if (!ctx.session?.userId || !ctx.from || !ctx.match) return;

    const targetGender = ctx.match[1] as any;
    const isVIP = ctx.session.isVIP || false;

    if (!isVIP) {
      const coinService = container.resolve<CoinService>(TOKENS.CoinService);
      const cost = CONSTANTS.FILTER_COST_GENDER;
      const success = await coinService.deductCoins(ctx.session.userId, cost, CoinTxType.SPEND_FILTER, `Gender Filter (${targetGender})`);
      if (!success) {
        const balance = await coinService.getBalance(ctx.session.userId);
        const err = ctx.t ? ctx.t('search.no_coins', { cost, balance }) : `❌ Insufficient coins (${balance}/${cost})`;
        await ctx.reply(err, { reply_markup: buildSearchModeKeyboard(ctx) });
        return;
      }
    }

    await performSearch(ctx, { gender: targetGender }, isVIP);
  });
}

/**
 * Helper to initiate search and notify both partners if connected
 */
async function performSearch(ctx: BotContext, filters: any, isVIP: boolean): Promise<void> {
  if (!ctx.session?.userId || !ctx.from) return;

  const matchService = container.resolve<MatchService>(TOKENS.MatchService);
  const telegramId = String(ctx.from.id);

  const activeSession = await matchService.startSearch(ctx.session.userId, telegramId, filters, isVIP);

  if (activeSession) {
    // Immediate match found! Notify both partner A and partner B
    await notifyPartnerConnected(ctx, activeSession);
  } else {
    // Added to queue
    const modeName = filters.priority ? 'VIP Priority ⚡' : filters.gender ? `Gender (${filters.gender}) 🚻` : 'Random 🎲';
    const msg = ctx.t ? ctx.t('search.searching', { mode: modeName }) : `⏳ Searching for a partner (${modeName})...`;
    
    await ctx.reply(msg, {
      reply_markup: buildSearchingKeyboard(ctx),
      parse_mode: 'Markdown',
    });
  }
}

/**
 * Notify both matched users that the chat has started
 */
export async function notifyPartnerConnected(ctx: BotContext, session: ActiveChatSession): Promise<void> {
  const foundMsg = ctx.t ? ctx.t('search.partner_found') : '🎉 Partner found! Say hello!';
  const replyMarkup = buildChatReplyKeyboard(ctx);
  const inlineControls = buildChatInlineControls(ctx, session.sessionId);

  // Notify Partner A
  try {
    await ctx.api.sendMessage(session.partnerA.telegramId, foundMsg, {
      reply_markup: replyMarkup,
      parse_mode: 'Markdown',
    });
    await ctx.api.sendMessage(session.partnerA.telegramId, '🎮 Controls:', {
      reply_markup: inlineControls,
    });
  } catch {
    // Ignore if partner A blocked
  }

  // Notify Partner B
  try {
    await ctx.api.sendMessage(session.partnerB.telegramId, foundMsg, {
      reply_markup: replyMarkup,
      parse_mode: 'Markdown',
    });
    await ctx.api.sendMessage(session.partnerB.telegramId, '🎮 Controls:', {
      reply_markup: inlineControls,
    });
  } catch {
    // Ignore if partner B blocked
  }
}
