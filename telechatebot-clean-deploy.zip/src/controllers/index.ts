import { Bot } from 'grammy';
import { BotContext } from '../types/bot';
import { registerAdminController } from './admin.controller';
import { registerStartController } from './start.controller';
import { registerProfileController } from './profile.controller';
import { registerEconomyController } from './economy.controller';
import { registerPremiumController } from './premium.controller';
import { registerGamificationController } from './gamification.controller';
import { registerSearchController } from './search.controller';
import { registerChatController } from './chat.controller';

export function setupControllers(bot: Bot<BotContext>): void {
  // 1. Register Admin & State controllers first
  registerAdminController(bot);

  // 2. Register Navigation & Commands
  registerStartController(bot);
  registerProfileController(bot);
  registerEconomyController(bot);
  registerPremiumController(bot);
  registerGamificationController(bot);

  // 3. Register Search & Matchmaking
  registerSearchController(bot);

  // 4. Register Chat Controls & Universal Message Relay (Must be registered last)
  registerChatController(bot);
}

export * from './start.controller';
export * from './search.controller';
export * from './chat.controller';
export * from './profile.controller';
export * from './economy.controller';
export * from './premium.controller';
export * from './gamification.controller';
export * from './admin.controller';
