import { Bot, InlineKeyboard } from 'grammy';
import { BotContext } from '../types/bot';
import { container, TOKENS } from '../core/container';
import { CoinService } from '../services/coin.service';

export function registerEconomyController(bot: Bot<BotContext>): void {
  // Coins & Wallet Menu button
  bot.hears(/coins|سکه‌ها|العملات|монеты|coin/i, async (ctx) => {
    await showWallet(ctx);
  });

  // Daily Login Reward Claim
  bot.callbackQuery('claim_daily', async (ctx) => {
    await ctx.answerCallbackQuery();
    if (!ctx.session?.userId) return;

    const coinService = container.resolve<CoinService>(TOKENS.CoinService);
    const res = await coinService.claimDailyReward(ctx.session.userId);

    if (res.success) {
      const msg = ctx.t ? ctx.t('economy.daily_reward', { amount: res.amount }) : `🎁 You received +${res.amount} daily login coins!`;
      await ctx.reply(msg);
    } else {
      const msg = ctx.t ? ctx.t('economy.daily_already_claimed') : 'ℹ️ You already claimed your daily reward today.';
      await ctx.reply(msg);
    }
    await showWallet(ctx);
  });

  // Lucky Spin Wheel
  bot.callbackQuery('spin_wheel', async (ctx) => {
    if (!ctx.session?.userId) return;
    const coinService = container.resolve<CoinService>(TOKENS.CoinService);
    const res = await coinService.spinWheel(ctx.session.userId);

    if (!res.success) {
      await ctx.answerCallbackQuery({ text: '❌ Insufficient coins (needs 10 coins)!' });
      return;
    }

    await ctx.answerCallbackQuery();
    await ctx.reply('🎡 Spinning the Lucky Wheel... ✨');
    
    setTimeout(async () => {
      const msg = ctx.t ? ctx.t('economy.spin_result', { prize: res.prize }) : `🎡 You spun the wheel and won ${res.prize} coins! 🎉`;
      await ctx.reply(msg);
      await showWallet(ctx);
    }, 1500);
  });
}

async function showWallet(ctx: BotContext): Promise<void> {
  if (!ctx.session?.userId) return;
  const coinService = container.resolve<CoinService>(TOKENS.CoinService);
  const balance = await coinService.getBalance(ctx.session.userId);

  const text = ctx.t
    ? ctx.t('economy.wallet_title', { balance })
    : `💰 **Your Wallet**\n🪙 Current Balance: **${balance} Coins**`;

  const t = ctx.t || ((k: string) => k);
  const kb = new InlineKeyboard()
    .text('🎁 Claim Daily Login Reward', 'claim_daily').row()
    .text(t('economy.spin_wheel'), 'spin_wheel').row()
    .text(t('menu.back'), 'menu_back');

  await ctx.reply(text, { reply_markup: kb, parse_mode: 'Markdown' });
}
