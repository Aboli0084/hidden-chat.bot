import 'reflect-metadata';
import { run, RunnerHandle } from '@grammyjs/runner';
import { config } from './config';
import { logger } from './config/logger';
import { checkDatabaseConnection, prisma } from './database/prisma';
import { checkRedisConnection, redis } from './database/redis';
import { createBot } from './bot';
import { setupControllers } from './controllers';

let runner: RunnerHandle | undefined;

async function bootstrap(): Promise<void> {
  logger.info('🚀 Starting Anonymous Telegram Chat Bot...');
  logger.info(`🌍 Environment: ${config.NODE_ENV}`);

  // 1. Check Database Connections
  logger.info('🔍 Checking PostgreSQL Database Connection...');
  const isDbConnected = await checkDatabaseConnection();
  if (!isDbConnected) {
    logger.error('❌ Failed to connect to PostgreSQL Database. Exiting...');
    process.exit(1);
  }

  logger.info('🔍 Checking Redis Cache & Queue Connection...');
  const isRedisConnected = await checkRedisConnection();
  if (!isRedisConnected) {
    logger.error('❌ Failed to connect to Redis. Exiting...');
    process.exit(1);
  }

  // 2. Initialize Bot & Controllers
  logger.info('🤖 Initializing grammy Bot...');
  const bot = createBot();
  setupControllers(bot);

  // 3. Start Bot with High-Performance Concurrent Runner
  logger.info('⚡ Starting Concurrent Long Polling via @grammyjs/runner...');
  runner = run(bot, {
    runner: {
      fetch: {
        allowed_updates: [
          'message',
          'edited_message',
          'callback_query',
          'my_chat_member',
          'chat_member',
        ],
      },
    },
  });

  const botInfo = await bot.api.getMe();
  logger.info(`✅ Bot @${botInfo.username} (${botInfo.id}) is online and ready!`);
  logger.info('🚀 Application successfully started on TelebotHost architecture.');
}

// Graceful Shutdown Handler
async function gracefulShutdown(signal: string): Promise<void> {
  logger.warn(`🛑 Received signal: ${signal}. Initiating graceful shutdown...`);

  if (runner && runner.isRunning()) {
    logger.info('🛑 Stopping grammy runner...');
    await runner.stop();
    logger.info('✅ grammy runner stopped.');
  }

  logger.info('🛑 Closing Redis connection...');
  await redis.quit();
  logger.info('✅ Redis connection closed.');

  logger.info('🛑 Disconnecting Prisma ORM...');
  await prisma.$disconnect();
  logger.info('✅ Prisma disconnected.');

  logger.info('👋 Graceful shutdown complete. Exiting process.');
  process.exit(0);
}

// Process Error Handlers
process.on('SIGINT', () => gracefulShutdown('SIGINT'));
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));

process.on('uncaughtException', (err: Error) => {
  logger.error('🚨 Uncaught Exception:', err);
  // Optional: trigger notification or restart depending on monitoring setup
});

process.on('unhandledRejection', (reason: any, promise: Promise<any>) => {
  logger.error('🚨 Unhandled Rejection at:', promise, 'reason:', reason);
});

// Run Application
bootstrap().catch((err) => {
  logger.error('🚨 Fatal error during bootstrap:', err);
  process.exit(1);
});
