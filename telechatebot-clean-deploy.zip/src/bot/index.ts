import { Bot, session, BotError, GrammyError, HttpError } from 'grammy';
import { hydrate } from '@grammyjs/hydrate';
import { BotContext, SessionData } from '../types/bot';
import { config } from '../config';
import { logger } from '../config/logger';
import { RedisSessionStorage } from './session-storage';
import {
  loggerMiddleware,
  authMiddleware,
  banCheckMiddleware,
  rateLimitMiddleware,
  captchaMiddleware,
} from '../middlewares';

export function createBot(): Bot<BotContext> {
  const bot = new Bot<BotContext>(config.BOT_TOKEN);

  // 1. Hydrate context with helper methods (ctx.replyWithPhoto, etc.)
  bot.use(hydrate());

  // 2. Redis Session storage
  bot.use(
    session({
      initial: (): SessionData => ({
        isCaptchaVerified: false,
      }),
      storage: new RedisSessionStorage(),
    }),
  );

  // 3. Middlewares Pipeline
  bot.use(loggerMiddleware);
  bot.use(authMiddleware);
  bot.use(banCheckMiddleware);
  bot.use(rateLimitMiddleware);
  bot.use(captchaMiddleware);

  // 4. Global Error Handler
  bot.catch((err: BotError<BotContext>) => {
    const ctx = err.ctx;
    logger.error(`🚨 Error while handling update ${ctx.update.update_id}:`);
    const e = err.error;

    if (e instanceof GrammyError) {
      logger.error(`GrammyError in request: ${e.description}`);
    } else if (e instanceof HttpError) {
      logger.error(`HttpError could not contact Telegram: ${e}`);
    } else {
      logger.error('Unknown Bot Error:', e);
    }

    try {
      const msg = ctx.t ? ctx.t('errors.general') : '❌ An unexpected error occurred. Please try again later.';
      ctx.reply(msg).catch(() => {});
    } catch {
      // Ignore reply errors
    }
  });

  return bot;
}
