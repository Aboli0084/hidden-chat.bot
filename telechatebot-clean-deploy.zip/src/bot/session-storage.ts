import { StorageAdapter } from 'grammy';
import { redis } from '../database/redis';
import { CONSTANTS } from '../config/constants';
import { SessionData } from '../types/bot';

export class RedisSessionStorage implements StorageAdapter<SessionData> {
  private prefix = `${CONSTANTS.REDIS_PREFIX}${CONSTANTS.REDIS_KEYS.SESSION}`;
  private ttl = CONSTANTS.LEADERBOARD_CACHE_TTL_SEC * 12; // 1 hour TTL for idle session

  async read(key: string): Promise<SessionData | undefined> {
    const raw = await redis.get(`${this.prefix}${key}`);
    if (!raw) return undefined;
    try {
      return JSON.parse(raw) as SessionData;
    } catch {
      return undefined;
    }
  }

  async write(key: string, value: SessionData): Promise<void> {
    const str = JSON.stringify(value);
    await redis.setex(`${this.prefix}${key}`, this.ttl, str);
  }

  async delete(key: string): Promise<void> {
    await redis.del(`${this.prefix}${key}`);
  }
}
