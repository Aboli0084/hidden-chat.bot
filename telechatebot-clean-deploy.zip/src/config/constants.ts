export const CONSTANTS = {
  DEFAULT_LOCALE: 'en',
  SUPPORTED_LOCALES: ['en', 'fa', 'ar', 'ru', 'tr'],
  
  // Redis Keys & Prefixes
  REDIS_PREFIX: 'telechate:',
  REDIS_KEYS: {
    QUEUE_VIP: 'queue:vip',
    QUEUE_STANDARD: 'queue:standard',
    ACTIVE_SESSION_BY_USER: 'session:user:',     // Append telegramId -> returns JSON of ActiveChatSession
    ACTIVE_SESSION_BY_ID: 'session:id:',         // Append sessionId -> returns JSON of ActiveChatSession
    USER_RATE_LIMIT: 'ratelimit:user:',          // Append telegramId
    RATE_LIMIT: 'ratelimit:user:',               // Alias for USER_RATE_LIMIT
    CAPTCHA_PENDING: 'captcha:pending:',         // Append telegramId
    USER_LAST_PARTNERS: 'partners:recent:',      // Set/List of recent partner userIds to prevent re-matching
    ONLINE_USERS_SET: 'users:online',            // Set of active user telegramIds in last 5 minutes
    STATS_DAILY: 'stats:daily:',                 // Daily counter prefix
    SESSION: 'session:data:',                    // grammy session storage prefix
    LEADERBOARD: 'leaderboard:xp',               // Sorted set for XP leaderboard
    USER_LOCK: 'lock:user:',                     // Distributed mutex lock for user operations
    BROADCAST_STATUS: 'broadcast:status:',       // Broadcast progress counter
  },

  // Pagination & Display
  ITEMS_PER_PAGE: 10,
  MAX_RECENT_PARTNERS: 5,
  SESSION_TIMEOUT_SEC: 86400, // 24 hours max chat session duration in Redis
  LEADERBOARD_CACHE_TTL_SEC: 300, // 5 minutes cache for leaderboard

  // Safety & Moderation
  RATE_LIMIT_MESSAGES: 10,       // Max messages per window
  RATE_LIMIT_WINDOW_SEC: 5,      // Window size in seconds
  AUTO_BAN_REPORT_COUNT: 5,      // Reports threshold for automatic temporary ban

  // Economy Defaults & Convenience Top-level Aliases
  DAILY_LOGIN_COINS: 10,
  REFERRAL_REWARD_COINS: 25,
  FILTER_COST_GENDER: 5,
  FILTER_COST_COUNTRY: 10,
  FILTER_COST_VIP: 15,

  ECONOMY: {
    DAILY_LOGIN_REWARD: 10,
    REFERRAL_REWARD: 25,
    GENDER_FILTER_COST: 5,
    COUNTRY_FILTER_COST: 10,
    SKIP_COST: 2,
    PRIORITY_MATCH_COST: 15,
  },

  // Premium VIP Prices in Coins (or Fiat equivalents)
  PREMIUM_PRICES: {
    MONTHLY: 100,
    THREE_MONTHS: 250,
    LIFETIME: 800,
  },

  // Gamification XP Rewards
  XP_REWARDS: {
    CHAT_COMPLETED: 15,
    LIKE_RECEIVED: 10,
    DAILY_LOGIN: 5,
  },
};
