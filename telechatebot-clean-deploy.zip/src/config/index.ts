import dotenv from 'dotenv';
import { z } from 'zod';

dotenv.config();

const configSchema = z.object({
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  PORT: z.string().transform(Number).default('3000'),
  LOG_LEVEL: z.string().default('info'),
  BOT_TOKEN: z.string().min(1, 'Telegram Bot Token is required'),
  BOT_USERNAME: z.string().default('TeleChateBotClone'),
  SUPER_ADMIN_IDS: z
    .string()
    .default('')
    .transform((str) =>
      str
        .split(',')
        .map((id) => id.trim())
        .filter((id) => id.length > 0),
    ),
  DATABASE_URL: z.string().min(1, 'Database URL is required'),
  REDIS_URL: z.string().optional(),
  REDIS_HOST: z.string().default('127.0.0.1'),
  REDIS_PORT: z.string().transform(Number).default('6379'),
  REDIS_PASSWORD: z.string().optional(),
  REDIS_DB: z.string().transform(Number).default('0'),
  ENABLE_CAPTCHA_FOR_NEW_USERS: z
    .string()
    .default('true')
    .transform((val) => val === 'true'),
  RATE_LIMIT_CHAT_MESSAGES: z.string().transform(Number).default('6'),
  RATE_LIMIT_COMMANDS: z.string().transform(Number).default('20'),
});

const parseConfig = () => {
  const result = configSchema.safeParse(process.env);
  if (!result.success) {
    console.error('❌ Invalid Environment Configuration:', result.error.format());
    throw new Error('Invalid environment variables. Please check your .env file.');
  }
  return result.data;
};

export const config = parseConfig();
export * from './constants';
