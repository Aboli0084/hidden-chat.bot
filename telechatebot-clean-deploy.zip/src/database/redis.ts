import Redis, { RedisOptions } from 'ioredis';
import { config } from '../config';
import { logger } from '../config/logger';

class RedisClientSingleton {
  private static instance: Redis;

  private constructor() {}

  public static getInstance(): Redis {
    if (!RedisClientSingleton.instance) {
      const redisOptions: RedisOptions = {
        maxRetriesPerRequest: null, // Required by BullMQ
        retryStrategy(times) {
          const delay = Math.min(times * 50, 2000);
          return delay;
        },
      };

      if (config.REDIS_URL && config.REDIS_URL.trim() !== '') {
        RedisClientSingleton.instance = new Redis(config.REDIS_URL, redisOptions);
      } else {
        RedisClientSingleton.instance = new Redis({
          ...redisOptions,
          host: config.REDIS_HOST,
          port: config.REDIS_PORT,
          password: config.REDIS_PASSWORD || undefined,
          db: config.REDIS_DB,
        });
      }

      RedisClientSingleton.instance.on('connect', () => {
        logger.info('✅ Connected to Redis.');
      });

      RedisClientSingleton.instance.on('error', (err) => {
        logger.error('❌ Redis Connection Error:', err);
      });
    }

    return RedisClientSingleton.instance;
  }
}

export const redis = RedisClientSingleton.getInstance();

// Helper functions for common Redis operations in our domain
export const redisHelpers = {
  async setJson(key: string, value: any, ttlSec?: number): Promise<void> {
    const str = JSON.stringify(value);
    if (ttlSec && ttlSec > 0) {
      await redis.setex(key, ttlSec, str);
    } else {
      await redis.set(key, str);
    }
  },

  async getJson<T>(key: string): Promise<T | null> {
    const str = await redis.get(key);
    if (!str) return null;
    try {
      return JSON.parse(str) as T;
    } catch (e) {
      logger.error(`Error parsing JSON from Redis key ${key}:`, e);
      return null;
    }
  },

  async deleteKey(key: string): Promise<number> {
    return await redis.del(key);
  },

  async addToSet(key: string, value: string): Promise<number> {
    return await redis.sadd(key, value);
  },

  async removeFromSet(key: string, value: string): Promise<number> {
    return await redis.srem(key, value);
  },

  async isMemberOfSet(key: string, value: string): Promise<boolean> {
    const res = await redis.sismember(key, value);
    return res === 1;
  },

  async increment(key: string, by = 1): Promise<number> {
    if (by === 1) return await redis.incr(key);
    return await redis.incrby(key, by);
  },

  async expire(key: string, ttlSec: number): Promise<number> {
    return await redis.expire(key, ttlSec);
  },
};

export async function checkRedisConnection(): Promise<boolean> {
  try {
    const res = await redis.ping();
    return res === 'PONG';
  } catch (error) {
    logger.error('Redis connection check failed:', error);
    return false;
  }
}
