import { PrismaClient } from '@prisma/client';
import { logger } from '../config/logger';

class PrismaClientSingleton {
  private static instance: PrismaClient;

  private constructor() {}

  public static getInstance(): PrismaClient {
    if (!PrismaClientSingleton.instance) {
      PrismaClientSingleton.instance = new PrismaClient({
        log: process.env.NODE_ENV === 'development' ? ['query', 'info', 'warn', 'error'] : ['error'],
      });

      PrismaClientSingleton.instance
        .$connect()
        .then(() => {
          logger.info('✅ Connected to PostgreSQL Database via Prisma.');
        })
        .catch((error) => {
          logger.error('❌ Failed to connect to PostgreSQL Database:', error);
        });
    }

    return PrismaClientSingleton.instance;
  }
}

export const prisma = PrismaClientSingleton.getInstance();
export default prisma;

export async function checkDatabaseConnection(): Promise<boolean> {
  try {
    await prisma.$queryRaw`SELECT 1`;
    return true;
  } catch (error) {
    logger.error('Database connection check failed:', error);
    return false;
  }
}
