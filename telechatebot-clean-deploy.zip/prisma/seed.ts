import { PrismaClient, UserRole, UserStatus } from '@prisma/client';
import dotenv from 'dotenv';

dotenv.config();

const prisma = new PrismaClient();

async function main() {
  console.info('🌱 Starting database seeding...');

  // 1. Seed Default Settings
  const defaultSettings = [
    { key: 'bot_status', value: JSON.stringify('ACTIVE'), description: 'Global bot operational status' },
    { key: 'maintenance_message', value: JSON.stringify('The bot is currently undergoing scheduled maintenance. Please try again later.'), description: 'Message shown during maintenance' },
    { key: 'coin_daily_login_reward', value: JSON.stringify(10), description: 'Coins rewarded for daily login streak' },
    { key: 'coin_referral_reward', value: JSON.stringify(25), description: 'Coins rewarded for successful referral' },
    { key: 'coin_cost_gender_filter', value: JSON.stringify(5), description: 'Cost in coins to use gender filter' },
    { key: 'coin_cost_country_filter', value: JSON.stringify(10), description: 'Cost in coins to use country filter' },
    { key: 'coin_cost_skip', value: JSON.stringify(2), description: 'Cost in coins to skip partner instantly' },
    { key: 'coin_cost_priority_match', value: JSON.stringify(15), description: 'Cost in coins for priority VIP matchmaking' },
    { key: 'min_age_limit', value: JSON.stringify(13), description: 'Minimum allowed age in profile' },
    { key: 'max_age_limit', value: JSON.stringify(99), description: 'Maximum allowed age in profile' },
    { key: 'report_auto_ban_threshold', value: JSON.stringify(5), description: 'Number of unresolved reports before auto temp-ban' },
  ];

  for (const setting of defaultSettings) {
    await prisma.setting.upsert({
      where: { key: setting.key },
      update: { value: setting.value, description: setting.description },
      create: { key: setting.key, value: setting.value, description: setting.description },
    });
  }
  console.info('✅ Default settings seeded.');

  // 2. Seed Super Admin(s) from Environment Variables
  const superAdminIdsStr = process.env.SUPER_ADMIN_IDS || '';
  const adminIds = superAdminIdsStr
    .split(',')
    .map((id) => id.trim())
    .filter((id) => id.length > 0);

  for (const telegramId of adminIds) {
    const existingAdmin = await prisma.user.findUnique({
      where: { telegramId },
    });

    if (!existingAdmin) {
      const referralCode = `ADMIN_${telegramId}_${Math.random().toString(36).substring(2, 7).toUpperCase()}`;
      const newAdmin = await prisma.user.create({
        data: {
          telegramId,
          username: `Admin_${telegramId}`,
          firstName: 'Super Admin',
          role: UserRole.SUPER_ADMIN,
          status: UserStatus.ACTIVE,
          coins: 999999,
          referralCode,
          profile: {
            create: {
              gender: 'UNSPECIFIED',
              country: 'GLOBAL',
              bio: 'System Administrator',
              xp: 10000,
              level: 100,
            },
          },
        },
      });
      console.info(`✅ Created Super Admin with Telegram ID: ${newAdmin.telegramId}`);
    } else if (existingAdmin.role !== UserRole.SUPER_ADMIN) {
      await prisma.user.update({
        where: { telegramId },
        data: { role: UserRole.SUPER_ADMIN },
      });
      console.info(`✅ Promoted existing user ${telegramId} to SUPER_ADMIN.`);
    } else {
      console.info(`ℹ️ Super Admin ${telegramId} already exists.`);
    }
  }

  console.info('🌱 Seeding completed successfully!');
}

main()
  .catch((e) => {
    console.error('❌ Error during seeding:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
