# 🛠️ راهنمای جامع نصب و پیکربندی (Installation Guide)

این مستند مراحل دقیق نصب، تنظیم متغیرهای محیطی، راه‌اندازی دیتابیس PostgreSQL و سرور Redis را برای اجرای ربات چت ناشناس تشریح می‌کند.

---

## ۱. پیش‌نیازهای نرم‌افزاری (System Requirements)
قبل از شروع نصب، مطمئن شوید نرم‌افزارهای زیر روی سرور یا سیستم شما نصب شده‌اند:

- **Node.js**: نسخه 22.x یا بالاتر (پیشنهاد می‌شود از `nvm` برای مدیریت نسخه‌های Node استفاده کنید).
- **PostgreSQL**: نسخه 14 یا بالاتر (برای ذخیره‌سازی کاربران، مکالمات، تراکنش‌های مالی و لاگ‌ها).
- **Redis**: نسخه 6 یا بالاتر (برای صف انتظار تطبیق سریع، مدیریت نشست‌ها و محدودیت نرخ پیام).
- **Git**: برای دریافت سورس کد پروژه.

---

## ۲. دریافت سورس کد و نصب وابستگی‌ها

ابتدا مخزن پروژه را کلون کرده و وارد پوشه پروژه شوید:
```bash
git clone https://github.com/yourusername/telechatebot-clone.git
cd telechatebot-clone
```

با استفاده از دستور زیر، تمامی وابستگی‌های پروژه (Prisma, grammY, BullMQ, TSyringe و...) را نصب کنید:
```bash
npm install --no-audit
```
> [!NOTE]
> در صورتی که روی سرور لینوکس هستید، پیشنهاد می‌شود تایپ اسکریپت و PM2 را به صورت گلوبال نیز نصب داشته باشید:
> `npm install -g typescript pm2`

---

## ۳. پیکربندی متغیرهای محیطی (Environment Variables)

فایل نمونه `.env.example` را به `.env` کپی کنید:
```bash
cp .env.example .env
```

فایل `.env` را با ویرایشگر متنی (مانند `nano` یا `vim`) باز کرده و مقادیر مربوط به ربات و دیتابیس خود را وارد کنید:

```env
# وضعیت اجرای برنامه (production برای سرور اصلی، development برای تست)
NODE_ENV=production
PORT=3000
LOG_LEVEL=info

# اطلاعات ربات تلگرام (دریافتی از @BotFather)
BOT_TOKEN="123456789:ABCdefGHIjklMNOpqrsTUVwxyz"
BOT_USERNAME="YourAwesomeAnonBot"

# شناسه تلگرام سوپر ادمین‌ها (با کاما جدا شود)
SUPER_ADMIN_IDS="123456789,987654321"

# رشته اتصال به دیتابیس PostgreSQL
DATABASE_URL="postgresql://username:password@localhost:5432/telechate?schema=public"

# تنظیمات اتصال به Redis
REDIS_HOST="127.0.0.1"
REDIS_PORT=6379
REDIS_PASSWORD=""
REDIS_DB=0
```

---

## ۴. راه‌اندازی و آماده‌سازی دیتابیس (Prisma Setup)

برای اینکه اورم Prisma بتواند جداول را در دیتابیس PostgreSQL بسازد و تایپ‌های تایپ اسکریپت را تولید کند، مراحل زیر را به ترتیب اجرا کنید:

### الف) تولید کلاینت پریزما (Prisma Client Generation)
```bash
npx prisma generate
```

### ب) ایجاد جداول در دیتابیس (Schema Push)
```bash
npx prisma db push
```

### ج) اجرای فایل سید (Database Seeding)
فایل سید برای ثبت تنظیمات پیش‌فرض اقتصاد ربات (مقدار سکه ورود روزانه، پاداش دعوت و...) و ایجاد رکورد ادمین‌های اولیه در دیتابیس استفاده می‌شود:
```bash
npx ts-node prisma/seed.ts
```

---

## ۵. کامپایل پروژه (TypeScript Build)

از آنجا که پروژه با TypeScript نوشته شده است، قبل از اجرا در محیط تولید (Production) باید به کدهای جاوا اسکریپت استاندارد کامپایل شود:
```bash
npm run build
```
پس از اجرای موفق این دستور، تمامی کدهای کامپایل شده در پوشه `dist/` قرار می‌گیرند.

---

## ۶. تست اجرای اولیه (Verification)

برای اطمینان از صحت عملکرد دیتابیس، ریدیس و اتصال به تلگرام، پروژه را یک‌بار در حالت توسعه اجرا کنید:
```bash
npm run dev
```
اگر پیام‌های زیر را در کنسول مشاهده کردید، نصب شما با موفقیت به اتمام رسیده است:
```
✅ Connected to PostgreSQL Database via Prisma.
✅ Connected to Redis.
✅ BullMQ Broadcast Queue initialized.
🚀 TeleChateBot (@YourAwesomeAnonBot) is running in production mode!
```

اکنون می‌توانید ربات خود را در تلگرام استارت کرده و برای استقرار دائم به مستند [DEPLOYMENT.md](./DEPLOYMENT.md) مراجعه نمایید.
