# 🚀 راهنمای استقرار در سرور و هاست (Deployment Guide)

این مستند روش‌های استقرار ربات چت ناشناس در محیط تولید (Production) را توضیح می‌دهد. با توجه به درخواست اختصاصی پروژه، بخش اول به صورت ویژه به استقرار روی هاست تخصصی **[TeleBotHost.com](https://telebothost.com)** اختصاص یافته است.

---

## 🌟 بخش ۱: استقرار اختصاصی روی هاست TeleBotHost.com (پیشنهاد اصلی)

هاست تخصصی **TeleBotHost.com** یکی از بهترین و بهینه‌ترین بسترها برای میزبانی ربات‌های تلگرامی نوشته شده با Node.js و TypeScript است. این هاست امکانات پیش‌فرض نظیر دیتابیس PostgreSQL، کش Redis، دسترسی به ترمینال (Terminal/SSH) و مدیریت پردازش‌ها با PM2 را در اختیار شما قرار می‌دهد.

### مرحله ۱: خرید سرویس و آماده‌سازی دیتابیس در پنل TeleBotHost
1. وارد پنل کاربری خود در سایت **TeleBotHost.com** شوید.
2. از بخش **دیتابیس‌ها (Databases)**:
   - یک دیتابیس **PostgreSQL** بسازید و نام کاربری، رمز عبور، هاست و پورت اتصال آن را یادداشت کنید.
   - یک نمونه **Redis** ایجاد کرده و آدرس هاست و پورت (و رمز عبور در صورت وجود) را یادداشت نمایید.
3. مطمئن شوید نسخه **Node.js** در تنظیمات سرویس شما روی **Node.js 22** تنظیم شده باشد.

### مرحله ۲: انتقال پروژه به هاست
شما می‌توانید فایل‌های پروژه را به یکی از دو روش زیر وارد هاست کنید:
- **روش الف (از طریق Git - پیشنهادی):** در ترمینال پنل TeleBotHost دستور زیر را وارد کنید تا پروژه از گیت‌هاب کلون شود:
  ```bash
  git clone https://github.com/yourusername/telechatebot-clone.git .
  ```
- **روش ب (از طریق File Manager):** فایل‌های پروژه (به جز پوشه `node_modules` و `dist`) را زیپ کرده و در فایل منیجر هاست آپلود و اکسترکت کنید.

### مرحله ۳: تنظیم فایل `.env` در TeleBotHost
در ترمینال هاست یا از طریق ویرایشگر فایل منیجر، فایل `.env` را ایجاد کرده و اطلاعات دیتابیس‌های دریافتی از پنل TeleBotHost را وارد کنید:
```env
NODE_ENV=production
PORT=3000
LOG_LEVEL=info

BOT_TOKEN="YOUR_TELEGRAM_BOT_TOKEN_FROM_BOTFATHER"
BOT_USERNAME="YourBotUsername"
SUPER_ADMIN_IDS="123456789"

# رشته اتصال دیتابیس PostgreSQL دریافتی از TeleBotHost
DATABASE_URL="postgresql://username:password@pg.telebothost.com:5432/dbname?schema=public"

# اطلاعات اتصال Redis دریافتی از TeleBotHost
REDIS_HOST="redis.telebothost.com"
REDIS_PORT=6379
REDIS_PASSWORD="your_redis_password_if_any"
```

### مرحله ۴: نصب پکیج‌ها و بیلید (در ترمینال TeleBotHost)
در ترمینال پنل مدیریت هاست، دستورات زیر را به ترتیب اجرا کنید:
```bash
# ۱. نصب پکیج‌های پروژه
npm install --no-audit

# ۲. تولید تایپ‌های کلاینت پریزما
npx prisma generate

# ۳. ایجاد جداول در دیتابیس PostgreSQL هاست
npx prisma db push

# ۴. اجرای سید برای ساخت ادمین و تنظیمات اولیه
npx ts-node prisma/seed.ts

# ۵. کامپایل پروژه از تایپ اسکریپت به جاوا اسکریپت
npm run build
```

### مرحله ۵: اجرای دائم ربات در TeleBotHost با PM2
هاست TeleBotHost به صورت کامل از پروسس منیجر **PM2** پشتیبانی می‌کند. فایل `ecosystem.config.js` در پروژه برای همین منظور آماده شده است.
در ترمینال هاست دستور زیر را اجرا کنید:
```bash
npx pm2 start ecosystem.config.js
npx pm2 save
```
برای مشاهده وضعیت اجرای ربات و لاگ‌های زنده:
```bash
npx pm2 status
npx pm2 logs telechatebot
```
**🎉 تبریک! ربات چت ناشناس شما اکنون روی سرورهای پرقدرت TeleBotHost.com با سرعت بالا در حال کار است.**

---

## 🖥️ بخش ۲: استقرار روی سرور مجازی (VPS - Linux / Ubuntu)

در صورتی که قصد اجرای پروژه روی سرور مجازی اختصاصی (مانند Hetzner، DigitalOcean، پارس‌پک و...) را دارید:

### ۱. نصب Node.js 22، PostgreSQL و Redis روی سرور Ubuntu
```bash
# آپدیت پکیج‌ها
sudo apt update && sudo apt upgrade -y

# نصب Redis و PostgreSQL
sudo apt install postgresql postgresql-contrib redis-server git -y
sudo systemctl enable postgresql redis-server
sudo systemctl start postgresql redis-server

# نصب Node.js 22 با استفاده از NodeSource
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs

# نصب PM2 و TypeScript به صورت گلوبال
sudo npm install -g pm2 typescript
```

### ۲. ساخت دیتابیس در PostgreSQL سرور
```bash
sudo -u postgres psql -c "CREATE USER telechate WITH PASSWORD 'StrongPassword123';"
sudo -u postgres psql -c "CREATE DATABASE telechatedb OWNER telechate;"
```

### ۳. راه‌اندازی پروژه
کدهای پروژه را کلون کرده، وابستگی‌ها را نصب و بیلد کنید:
```bash
git clone https://github.com/yourusername/telechatebot-clone.git
cd telechatebot-clone
npm install --no-audit
cp .env.example .env
# ویرایش .env و قرار دادن رشته اتصال:
# DATABASE_URL="postgresql://telechate:StrongPassword123@localhost:5432/telechatedb?schema=public"

npx prisma generate
npx prisma db push
npx ts-node prisma/seed.ts
npm run build
pm2 start ecosystem.config.js
pm2 save
pm2 startup
```

---

## 🐳 بخش ۳: استقرار با Docker و Docker Compose (آسان‌ترین روش کانتینری)

پروژه دارای فایل‌های مجهز `Dockerfile` و `docker-compose.yml` است که دیتابیس PostgreSQL، کش Redis و خود ربات را به صورت همزمان بالا می‌آورد.

### ۱. تنظیم فایل `.env`
فایل `.env` را در کنار `docker-compose.yml` ایجاد کنید. در حالت داکر، هاست‌های اتصال به دیتابیس و ریدیس نام سرویس‌ها در داکر هستند:
```env
NODE_ENV=production
BOT_TOKEN="YOUR_TELEGRAM_BOT_TOKEN"
BOT_USERNAME="YourBotUsername"
SUPER_ADMIN_IDS="123456789"

DATABASE_URL="postgresql://postgres:postgrespassword@postgres:5432/telechate?schema=public"
REDIS_HOST="redis"
REDIS_PORT=6379
```

### ۲. اجرای داکر کامپوز
در پوشه اصلی پروژه دستور زیر را اجرا کنید تا تمامی کانتینرها ساخته و اجرا شوند:
```bash
docker-compose up -d --build
```
برای مشاهده لاگ کانتینر ربات:
```bash
docker-compose logs -f bot
```
برای متوقف کردن کانتینرها:
```bash
docker-compose down
```

---

## 🛠️ نکات حیاتی استقرار در تولید (Production Best Practices)
1. **محدودیت حافظه (Memory Limit):** در فایل `ecosystem.config.js` محدودیت حافظه روی `500M` تنظیم شده است تا در صورت نشتی حافظه احتمالی در نشست‌های طولانی، PM2 به صورت خودکار ربات را ریستارت کند بدون اینکه مکالمات ذخیره شده در Redis از دست برود.
2. **پشتیبان‌گیری از دیتابیس (Backup):** حتماً یک کران جاب روزانه برای پشتیبان‌گیری از PostgreSQL با دستور `pg_dump` تنظیم کنید تا اطلاعات سکه‌ها و کاربران محفوظ بماند.
3. **ارتقای بدون قطعی (Zero-Downtime Update):** برای آپدیت کدهای ربات در آینده بدون قطع شدن اتصال کاربران فعلی:
   ```bash
   git pull
   npm install
   npx prisma generate && npx prisma db push
   npm run build
   npx pm2 reload telechatebot
   ```
