# 🔌 مستندات فنی و معماری داخلی (Technical & API Documentation)

این مستند برای توسعه‌دهندگان و مهندسان نرم‌افزاری تدوین شده است که قصد بررسی عمیق معماری، لایه‌های سرویس، ساختار کلیدهای Redis و الگوهای طراحی پیاده‌سازی شده در این پروژه را دارند.

---

## ۱. معماری نرم‌افزاری (Clean Architecture & SOLID)

این پروژه بر پایه اصول **Clean Architecture (معماری تمیز)** و رعایت کامل اصول ۵‌گانه **SOLID** ساخته شده است. وابستگی‌ها به صورت یک‌طرفه از لایه‌های بیرونی (کنترلرها و تلگرام) به سمت لایه‌های درونی (سرویس‌ها و دامنه) جریان دارند:

```
[ Telegram API / grammY Bot ]
            │
            ▼
[ Controllers & Middleware Layer ]  <-- اعتبارسنجی اولیه، مدیریت سشن و مسیردهی
            │
            ▼
[ Domain Services Layer (Business Logic) ] <-- منطق تجاری (تطبیق، مالی، گیمیفیکیشن)
            │
            ▼
[ Repository Layer (Data Access Interface) ] <-- تفکیک منطق داده با IRepository
            │
            ▼
[ Database & Infrastructure Layer ] <-- Prisma ORM (PostgreSQL) & ioredis & BullMQ
```

### مزایای کلیدی این معماری:
- **تست‌پذیری (Testability):** تمامی لایه‌ها به دلیل استفاده از 인터페이스‌های مشخص، به سادگی قابل Mock کردن در Unit Test هستند.
- **تزریق وابستگی (Dependency Injection):** تمامی سرویس‌ها و ریپازیتوری‌ها توسط کانتینر قدرتمند **TSyringe** مدیریت و به صورت سینگلتون تزریق می‌شوند.

---

## ۲. ساختار کانتینر و توکن‌های تزریق وابستگی (`src/core/container.ts`)

برای جلوگیری از وابستگی مستقیم به پیاده‌سازی‌ها (Dependency Inversion Principle)، تمامی وابستگی‌ها با توکن‌های نمادین (Symbols) رجیستر شده‌اند:

| توکن (Symbol Token) | کلاس پیاده‌سازی (Implementation) | توضیحات مسئولیت |
| :--- | :--- | :--- |
| `TOKENS.UserRepository` | `UserRepository` | عملیات CRUD روی کاربران در PostgreSQL |
| `TOKENS.ProfileRepository` | `ProfileRepository` | مدیریت پروفایل، سن، جنسیت، کشور و امتیازات |
| `TOKENS.ChatRepository` | `ChatRepository` | مدیریت نشست‌های چت و سابقه مکالمات |
| `TOKENS.CoinRepository` | `CoinRepository` | مدیریت تراکنش‌های مالی و سکه‌ها |
| `TOKENS.MatchService` | `MatchService` | الگوریتم تطبیق هوشمند و مدیریت صف‌ها در ریدیس |
| `TOKENS.ChatService` | `ChatService` | رله پیام‌ها، ارسال ناشناس و مدیریت Typing |
| `TOKENS.SafetyService` | `SafetyService` | محدودیت نرخ (Rate Limit) و سیستم ریپورت/بن |
| `TOKENS.QueueService` | `QueueService` | مدیریت صف‌های BullMQ برای برادکست و کارهای سنگین |

---

## ۳. ساختار داده و کلیدهای Redis (Redis Keys Schema)

ریدیس در این پروژه نقش قلب تپنده (In-Memory Data Grid) را ایفا می‌کند. کلیدهای زیر با پیشوند `telechate:` برای مدیریت بلادرنگ صف‌ها و نشست‌ها استفاده می‌شوند:

### الف) صف‌های انتظار (Matchmaking Queues):
- **`telechate:queue:vip`** (نوع: `List`): صف انتظار کاربران ویژه (VIP) که در الگوریتم تطبیق با اولویت اول بررسی و خارج می‌شوند (`RPOPLPUSH` / `LRANGE`).
- **`telechate:queue:standard`** (نوع: `List`): صف انتظار استاندارد کاربران عادی که بر اساس زمان ورود به صف پردازش می‌شوند.

### ب) نشست‌های چت فعال (Active Chat Sessions):
- **`telechate:session:user:{telegramId}`** (نوع: `String - JSON`): ذخیره اطلاعات نشست فعال کاربر با مدت زمان اعتبار ۲۴ ساعت (TTL). شامل شناسه دیتابیس، شناسه هم‌صحبت و وضعیت چت.
- **`telechate:session:id:{sessionId}`** (نوع: `String - JSON`): نقشه کمکی برای جستجوی سریع نشست بر اساس ID چت.

### ج) جلوگیری از تکرار هم‌صحبت (Recent Partners Anti-Repeat):
- **`telechate:partners:recent:{userId}`** (نوع: `Set`): شناسه عددی ۵ هم‌صحبت اخیر کاربر در این ست ذخیره می‌شود تا الگوریتم `MatchService` از اتصال مجدد به آن‌ها خودداری کند.

### د) محدودیت نرخ و امنیت (Rate Limiting Token Bucket):
- **`telechate:ratelimit:user:{telegramId}`** (نوع: `String` - Counter): شمارنده تعداد پیام‌های ارسالی کاربر در پنجره ۵ ثانیه‌ای. در صورت عبور از عدد ۱۰، پیام مسدود می‌شود.

---

## ۴. الگوریتم تطبیق هوشمند (Smart Matchmaking Engine)

الگوریتم تطبیق در کلاس `MatchService` (`src/services/match.service.ts`) به روش زیر عمل می‌کند:

```mermaid
sequenceDiagram
    participant U as کاربر (User)
    participant MS as MatchService
    participant R as Redis Queues
    participant DB as PostgreSQL (Prisma)
    
    U->>MS: درخواست شروع جستجو (startSearch)
    MS->>R: بررسی صف VIP و سپس صف Standard
    alt هم‌صحبت سازگار پیدا شد (Match Found)
        MS->>R: خروج هم‌صحبت از صف (lrem)
        MS->>DB: ایجاد رکورد ChatSession جدید
        MS->>R: ثبت نشست فعال برای هر دو کاربر (session:user)
        MS->>U: ارسال اعلان اتصال به چت (Partner Found)
    else هم‌صحبتی در صف نبود
        MS->>R: اضافه کردن کاربر به صف انتظار (rpush)
        MS->>U: ارسال پیام "در حال جستجو..."
    end
```

### شروط سازگاری در تطبیق (Compatibility Checks):
1. **عدم تکرار:** هم‌صحبت نباید جزو ۵ نفر اخیر ست `partners:recent` باشد.
2. **تطبیق جنسیت (Gender Filter):** در صورت درخواست جنسیت خاص (مثلاً خانم)، پروفایل طرف مقابل در دیتابیس بررسی می‌شود.
3. **تطبیق کشور (Country Filter):** در صورت انتخاب کشور، طرف مقابل باید دقیقاً از همان کشور باشد.

---

## ۵. اورم Prisma و ساختار پایگاه داده (Relational Schema)

مدل‌های داده در `prisma/schema.prisma` به صورت کاملاً نرمال‌سازی شده طراحی شده‌اند. روابط اصلی عبارتند از:

- **User**: رکورد اصلی کاربر (تلگرام ID، رول، زبان، آمار سکه).
- **Profile**: اطلاعات دموگرافیک (سن، جنسیت، کشور، بیو، سطح و XP) به صورت `1-to-1` با User.
- **ChatSession**: رکورد مکالمه به صورت `Many-to-Many` بین دو User (به عنوان `partnerA` و `partnerB`).
- **MessageLog**: لاگ پیام‌های رد و بدل شده (فقط متا دیتا و نوع پیام جهت حفظ حریم خصوصی؛ محتوای متنی اختیاری است) به صورت `1-to-Many` با ChatSession.
- **CoinTransaction**: ثبت دقیق تمامی تراکنش‌های مالی (افزایش/کاهش سکه) با ذکر دلیل و تاریخ جهت حسابرسی (Audit Trail).
- **PremiumSubscription**: سابقه و وضعیت اشتراک‌های ویژه VIP کاربران.
- **Report**: ثبت ریپورت‌ها و شکایات کاربران از هم‌صحبت‌ها جهت بررسی در پنل ادمین.
